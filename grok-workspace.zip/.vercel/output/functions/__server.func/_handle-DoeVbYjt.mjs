import { C as require_jsx_runtime, y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { i as Route$3 } from "./_ssr/router-Bgh4e7MR.mjs";
import { t as ProductBar } from "./_ssr/product-bar-DCcIP2rb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_handle-DoeVbYjt.js
var import_jsx_runtime = require_jsx_runtime();
function PublicIndex() {
	const { handle, issues } = Route$3.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductBar, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "content",
		className: "shell py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-eyebrow text-pine uppercase",
				children: "Public versions"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-section",
				children: handle
			}),
			issues.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 max-w-md text-muted",
				children: "Nothing is public at this address."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-10 divide-y divide-ink/15 border-y border-ink/15",
				children: issues.map((issue) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/p/$handle/$slug",
					params: {
						handle,
						slug: issue.slug
					},
					className: "block py-6 hover:bg-wash",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: issue.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-display text-3xl",
							children: issue.name || issue.title
						}),
						issue.headline ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-xl text-muted",
							children: issue.headline
						}) : null,
						issue.role ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm",
							children: issue.role
						}) : null
					]
				}) }, issue.slug))
			})
		]
	})] });
}
//#endregion
export { PublicIndex as component };
