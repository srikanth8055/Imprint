//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-9whvnRQR.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/login",
			"/plans",
			"/sample/bio",
			"/studio/$versionId",
			"/studio/",
			"/api/auth/$",
			"/p/$handle/$slug",
			"/p/$handle/"
		],
		preloads: [
			"/assets/index-B3crXYb3.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/portfolio.functions-Od7E10l3.js",
			"/assets/not-found-DIgawKw1.js",
			"/assets/link-CDMYz7w4.js",
			"/assets/matchContext-B4A6rP5h.js",
			"/assets/lazyRouteComponent-rovMd2lT.js",
			"/assets/useSelector-DVkoJ9pC.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B3crXYb3.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-NfHyzaUw.js",
			"/assets/product-bar-DEnkoVrG.js",
			"/assets/issue-view-BPxlJCoU.js",
			"/assets/specimen-gFEC3lyW.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-BYS4DEm-.js",
			"/assets/client-CzaTc0Rp.js",
			"/assets/product-bar-DEnkoVrG.js"
		]
	},
	"/plans": {
		filePath: "/workspace/src/routes/plans.tsx",
		children: void 0,
		preloads: [
			"/assets/plans-BZHznupL.js",
			"/assets/product-bar-DEnkoVrG.js",
			"/assets/portfolio-model-B6gbzWQH.js"
		]
	},
	"/sample/bio": {
		filePath: "/workspace/src/routes/sample.bio.tsx",
		children: void 0,
		preloads: [
			"/assets/sample.bio-DopxNuZm.js",
			"/assets/product-bar-DEnkoVrG.js",
			"/assets/issue-view-BPxlJCoU.js",
			"/assets/specimen-gFEC3lyW.js"
		]
	},
	"/studio/$versionId": {
		filePath: "/workspace/src/routes/studio/$versionId.tsx",
		children: void 0,
		preloads: ["/assets/_versionId-BfsH8gnk.js", "/assets/product-bar-DEnkoVrG.js"]
	},
	"/studio/": {
		filePath: "/workspace/src/routes/studio/index.tsx",
		children: void 0,
		preloads: [
			"/assets/studio-Dck_Jc_A.js",
			"/assets/product-bar-DEnkoVrG.js",
			"/assets/portfolio-model-B6gbzWQH.js"
		]
	},
	"/p/$handle/$slug": {
		filePath: "/workspace/src/routes/p/$handle/$slug.tsx",
		children: ["/p/$handle/$slug/bio", "/p/$handle/$slug/"],
		preloads: ["/assets/_slug-Bu1R_2ia.js"]
	},
	"/p/$handle/": {
		filePath: "/workspace/src/routes/p/$handle/index.tsx",
		children: void 0,
		preloads: ["/assets/_handle-DO0FjtJ5.js", "/assets/product-bar-DEnkoVrG.js"]
	},
	"/p/$handle/$slug/bio": {
		filePath: "/workspace/src/routes/p/$handle/$slug.bio.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug.bio-DEDTbwmA.js",
			"/assets/product-bar-DEnkoVrG.js",
			"/assets/issue-view-BPxlJCoU.js"
		]
	},
	"/p/$handle/$slug/": {
		filePath: "/workspace/src/routes/p/$handle/$slug.index.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug.index-Dz8rWnbk.js",
			"/assets/product-bar-DEnkoVrG.js",
			"/assets/issue-view-BPxlJCoU.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
