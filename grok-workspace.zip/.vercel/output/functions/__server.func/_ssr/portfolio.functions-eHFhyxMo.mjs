import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { i as getSql, t as authMiddleware } from "./middleware-yhXJe1_Z.mjs";
import { c as parseHandle, l as parseSlug, n as asPlan, o as normalizeContent, r as blankContent, t as PLAN_LIMITS, u as slugify } from "./portfolio-model-DyeoDMpX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/portfolio.functions-eHFhyxMo.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function fail(error) {
	return {
		ok: false,
		error
	};
}
function isUnique(err) {
	if (typeof err !== "object" || err === null) return false;
	if (("code" in err ? String(err.code) : "") === "23505") return true;
	return String(err).toLowerCase().includes("unique");
}
function readContent(value) {
	try {
		const parsed = typeof value === "string" ? JSON.parse(value) : value;
		return normalizeContent(parsed);
	} catch {
		return blankContent();
	}
}
function asBool(value) {
	return value === true || value === "t" || value === "true" || value === 1;
}
function asText(value) {
	return value == null ? "" : String(value);
}
async function limitFor(sql, userId) {
	const rows = await sql`select plan from profiles where user_id = ${userId}`;
	if (!rows[0]) return null;
	const plan = asPlan(rows[0].plan);
	return {
		plan,
		versions: PLAN_LIMITS[plan].versions
	};
}
async function freeSlug(sql, userId, base) {
	const root = parseSlug(base) ?? "issue";
	let candidate = root;
	for (let n = 2; n < 30; n += 1) {
		if ((await sql`select 1 as ok from versions where user_id = ${userId} and slug = ${candidate}`).length === 0) return candidate;
		const stem = root.replace(/-\d+$/, "").slice(0, 36).replace(/-+$/g, "") || "issue";
		candidate = parseSlug(`${stem}-${n}`) ?? `issue-${n}`;
	}
	return `issue-${Date.now().toString(36)}`;
}
var getStudio_createServerFn_handler = createServerRpc({
	id: "8391d7870f1c3d818c23e974a2de47a2ee2e2a7e6e9ab464b8e06445177cf420",
	name: "getStudio",
	filename: "src/lib/portfolio.functions.ts"
}, (opts) => getStudio.__executeServer(opts));
var getStudio = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getStudio_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	const profiles = await sql`
      select handle, plan from profiles where user_id = ${context.userId}
    `;
	if (!profiles[0]) return {
		ok: true,
		data: { profile: null }
	};
	const plan = asPlan(profiles[0].plan);
	const mapped = (await sql`
      select id, slug, title, is_public, content->>'name' as name, updated_at::text as updated_at
      from versions
      where user_id = ${context.userId}
      order by updated_at desc
    `).map((row) => ({
		id: row.id,
		slug: row.slug,
		title: row.title,
		isPublic: asBool(row.is_public),
		name: asText(row.name),
		updatedAt: asText(row.updated_at)
	}));
	return {
		ok: true,
		data: {
			profile: {
				handle: profiles[0].handle,
				plan,
				versionLimit: PLAN_LIMITS[plan].versions,
				used: mapped.length,
				publicCount: mapped.filter((row) => row.isPublic).length
			},
			versions: mapped
		}
	};
});
var claimHandle_createServerFn_handler = createServerRpc({
	id: "3739c6dd2c2b5e9019ebac0a1759889b6d5fa471dbe4d351b314ccfd1e1a9fa5",
	name: "claimHandle",
	filename: "src/lib/portfolio.functions.ts"
}, (opts) => claimHandle.__executeServer(opts));
var claimHandle = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((handle) => handle).handler(claimHandle_createServerFn_handler, async ({ context, data }) => {
	const handle = parseHandle(data);
	if (!handle) return fail("Use 3–24 letters, numbers, or single hyphens. Some names are reserved.");
	const sql = await getSql();
	try {
		await sql`insert into profiles (user_id, handle) values (${context.userId}, ${handle})`;
	} catch (err) {
		if (!isUnique(err)) throw err;
		if ((await sql`select 1 as ok from profiles where user_id = ${context.userId}`).length) return fail("You already claimed a public name.");
		return fail("That public name is taken.");
	}
	return {
		ok: true,
		data: { handle }
	};
});
var createVersion_createServerFn_handler = createServerRpc({
	id: "a971fe7184f65a9839c5328b6162288ae9d00719d645fc0814fc6cf50406b329",
	name: "createVersion",
	filename: "src/lib/portfolio.functions.ts"
}, (opts) => createVersion.__executeServer(opts));
var createVersion = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createVersion_createServerFn_handler, async ({ context, data }) => {
	const title = data.title.trim().slice(0, 60) || "Untitled issue";
	const sql = await getSql();
	const plan = await limitFor(sql, context.userId);
	if (!plan) return fail("Claim a public name before you add a version.");
	const id = crypto.randomUUID();
	const slug = await freeSlug(sql, context.userId, slugify(title));
	const content = JSON.stringify(blankContent());
	try {
		const rows = await sql`
        insert into versions (id, user_id, slug, title, is_public, content)
        select ${id}, ${context.userId}, ${slug}, ${title}, false, ${content}::jsonb
        where (select count(*) from versions where user_id = ${context.userId}) < ${plan.versions}
        returning id
      `;
		if (!rows[0]) return fail(plan.plan === "free" ? "Free keeps two versions. Become a subscriber to keep four." : "A subscriber keeps four versions. Remove one before adding another.");
		return {
			ok: true,
			data: { id: rows[0].id }
		};
	} catch (err) {
		if (isUnique(err)) return fail("That address is already used. Try again.");
		throw err;
	}
});
var getVersion_createServerFn_handler = createServerRpc({
	id: "86bee1e6038e386ad2897763e413353c536cdc20448c6af578b425e4c70ec1c1",
	name: "getVersion",
	filename: "src/lib/portfolio.functions.ts"
}, (opts) => getVersion.__executeServer(opts));
var getVersion = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((id) => id).handler(getVersion_createServerFn_handler, async ({ context, data }) => {
	const row = (await (await getSql())`
      select id, slug, title, is_public, content, updated_at::text as updated_at, content->>'name' as name
      from versions
      where id = ${data} and user_id = ${context.userId}
    `)[0];
	if (!row) return fail("That version is not in your studio.");
	const content = readContent(row.content);
	return {
		ok: true,
		data: {
			id: row.id,
			slug: row.slug,
			title: row.title,
			isPublic: asBool(row.is_public),
			name: content.name,
			updatedAt: asText(row.updated_at),
			content
		}
	};
});
var saveVersion_createServerFn_handler = createServerRpc({
	id: "eca24d494b9c59f2464c54c1dd6e5de005e2d1c59e9c89dba5563c7600299886",
	name: "saveVersion",
	filename: "src/lib/portfolio.functions.ts"
}, (opts) => saveVersion.__executeServer(opts));
var saveVersion = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(saveVersion_createServerFn_handler, async ({ context, data }) => {
	const title = data.title.trim().slice(0, 60);
	if (!title) return fail("Give this version a name.");
	const slug = parseSlug(data.slug);
	if (!slug) return fail("The public slug needs 2–40 letters, numbers, or single hyphens.");
	const packed = JSON.stringify(normalizeContent(data.content));
	if (packed.length > 8e4) return fail("This version is too long to save.");
	const sql = await getSql();
	try {
		const rows = await sql`
        update versions
        set title = ${title},
            slug = ${slug},
            content = ${packed}::jsonb,
            updated_at = now()
        where id = ${data.id} and user_id = ${context.userId}
        returning slug
      `;
		if (!rows[0]) return fail("That version is not in your studio.");
		return {
			ok: true,
			data: { slug: rows[0].slug }
		};
	} catch (err) {
		if (isUnique(err)) return fail("Another version already uses that slug.");
		throw err;
	}
});
var setVisibility_createServerFn_handler = createServerRpc({
	id: "6e5f2b0f9b671b7ef25dea271fa64570b65841278dad1c3c52a6b30a1f062f49",
	name: "setVisibility",
	filename: "src/lib/portfolio.functions.ts"
}, (opts) => setVisibility.__executeServer(opts));
var setVisibility = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(setVisibility_createServerFn_handler, async ({ context, data }) => {
	if (!(await (await getSql())`
      update versions
      set is_public = ${data.isPublic}, updated_at = now()
      where id = ${data.id} and user_id = ${context.userId}
      returning id
    `)[0]) return fail("That version is not in your studio.");
	return {
		ok: true,
		data: { isPublic: data.isPublic }
	};
});
var deleteVersion_createServerFn_handler = createServerRpc({
	id: "45db6df5c5ac2601d5a42ab0bcac12d901a025d0c14918198036df54c606f30e",
	name: "deleteVersion",
	filename: "src/lib/portfolio.functions.ts"
}, (opts) => deleteVersion.__executeServer(opts));
var deleteVersion = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => id).handler(deleteVersion_createServerFn_handler, async ({ context, data }) => {
	const rows = await (await getSql())`
      delete from versions where id = ${data} and user_id = ${context.userId} returning id
    `;
	if (!rows[0]) return fail("That version is not in your studio.");
	return {
		ok: true,
		data: { id: rows[0].id }
	};
});
var duplicateVersion_createServerFn_handler = createServerRpc({
	id: "ec051ad8f6a2b48e697be5d0e8881ec957e3a03a9bb01dfeb7b1994ab432c9c1",
	name: "duplicateVersion",
	filename: "src/lib/portfolio.functions.ts"
}, (opts) => duplicateVersion.__executeServer(opts));
var duplicateVersion = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => id).handler(duplicateVersion_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const plan = await limitFor(sql, context.userId);
	if (!plan) return fail("Claim a public name first.");
	const source = await sql`
      select title, content from versions where id = ${data} and user_id = ${context.userId}
    `;
	if (!source[0]) return fail("That version is not in your studio.");
	const id = crypto.randomUUID();
	const title = `Copy of ${source[0].title}`.slice(0, 60);
	const slug = await freeSlug(sql, context.userId, slugify(title));
	const content = JSON.stringify(readContent(source[0].content));
	const rows = await sql`
      insert into versions (id, user_id, slug, title, is_public, content)
      select ${id}, ${context.userId}, ${slug}, ${title}, false, ${content}::jsonb
      where (select count(*) from versions where user_id = ${context.userId}) < ${plan.versions}
      returning id
    `;
	if (!rows[0]) return fail(plan.plan === "free" ? "Free keeps two versions. Become a subscriber to keep four." : "A subscriber keeps four versions. Remove one before duplicating.");
	return {
		ok: true,
		data: { id: rows[0].id }
	};
});
var setPlan_createServerFn_handler = createServerRpc({
	id: "33c7a196714d609d6d68e8b7887e2a3edf2f6f8b3ae178ed5144e94485259f71",
	name: "setPlan",
	filename: "src/lib/portfolio.functions.ts"
}, (opts) => setPlan.__executeServer(opts));
var setPlan = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((plan) => plan).handler(setPlan_createServerFn_handler, async ({ context, data }) => {
	const plan = asPlan(data);
	if (data !== "free" && data !== "subscriber") return fail("Unknown plan.");
	const sql = await getSql();
	if (plan === "subscriber") {
		if (!(await sql`
        update profiles set plan = 'subscriber' where user_id = ${context.userId} returning user_id
      `)[0]) return fail("Claim a public name before changing plans.");
		return {
			ok: true,
			data: { plan }
		};
	}
	if ((await sql`
      update profiles
      set plan = 'free'
      where user_id = ${context.userId}
        and (select count(*) from versions where user_id = ${context.userId}) <= ${PLAN_LIMITS.free.versions}
      returning user_id
    `)[0]) return {
		ok: true,
		data: { plan: "free" }
	};
	if (!(await sql`select 1 as ok from profiles where user_id = ${context.userId}`)[0]) return fail("Claim a public name before changing plans.");
	return fail("Free keeps two versions. Remove extras before you move back.");
});
var listPublicIssues_createServerFn_handler = createServerRpc({
	id: "77917f9d0b6d82e7932f85c1d3a72ab7765d71f0f0a7986877bb871c83c77b18",
	name: "listPublicIssues",
	filename: "src/lib/portfolio.functions.ts"
}, (opts) => listPublicIssues.__executeServer(opts));
var listPublicIssues = createServerFn({ method: "GET" }).validator((handle) => handle).handler(listPublicIssues_createServerFn_handler, async ({ data }) => {
	const handle = data.trim().toLowerCase();
	if (!/^[a-z0-9-]{2,40}$/.test(handle)) return [];
	return (await (await getSql())`
      select v.slug, v.title,
             v.content->>'name' as name,
             v.content->>'role' as role,
             v.content->>'headline' as headline
      from versions v
      join profiles p on p.user_id = v.user_id
      where p.handle = ${handle} and v.is_public = true
      order by v.updated_at desc
    `).map((row) => ({
		slug: row.slug,
		title: row.title,
		name: asText(row.name),
		role: asText(row.role),
		headline: asText(row.headline)
	}));
});
var getPublicIssue_createServerFn_handler = createServerRpc({
	id: "7587ea89450c090645bf5f5b91aaaba4524ddf67ca3078382ad244ed313e445a",
	name: "getPublicIssue",
	filename: "src/lib/portfolio.functions.ts"
}, (opts) => getPublicIssue.__executeServer(opts));
var getPublicIssue = createServerFn({ method: "GET" }).validator((input) => input).handler(getPublicIssue_createServerFn_handler, async ({ data }) => {
	const handle = data.handle.trim().toLowerCase();
	const slug = data.slug.trim().toLowerCase();
	if (!/^[a-z0-9-]{2,40}$/.test(handle) || !/^[a-z0-9-]{2,40}$/.test(slug)) return null;
	const row = (await (await getSql())`
      select v.slug, v.title, v.content, v.updated_at::text as updated_at
      from versions v
      join profiles p on p.user_id = v.user_id
      where p.handle = ${handle} and v.slug = ${slug} and v.is_public = true
    `)[0];
	if (!row) return null;
	return {
		slug: row.slug,
		title: row.title,
		updatedAt: asText(row.updated_at),
		content: readContent(row.content)
	};
});
//#endregion
export { claimHandle_createServerFn_handler, createVersion_createServerFn_handler, deleteVersion_createServerFn_handler, duplicateVersion_createServerFn_handler, getPublicIssue_createServerFn_handler, getStudio_createServerFn_handler, getVersion_createServerFn_handler, listPublicIssues_createServerFn_handler, saveVersion_createServerFn_handler, setPlan_createServerFn_handler, setVisibility_createServerFn_handler };
