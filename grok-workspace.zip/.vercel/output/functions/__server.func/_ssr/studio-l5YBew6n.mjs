import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Z as require_react, x as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as deleteVersion, l as duplicateVersion, m as setVisibility, o as claimHandle, s as createVersion, u as getStudio } from "./router-Bgh4e7MR.mjs";
import { n as RedirectToSignIn, r as useCurrentUserState, t as ProductBar } from "./product-bar-DCcIP2rb.mjs";
import { c as parseHandle, t as PLAN_LIMITS } from "./portfolio-model-DyeoDMpX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/studio-l5YBew6n.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StudioGate() {
	const { user, isPending } = useCurrentUserState();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductBar, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "shell py-20 text-muted",
		children: "Opening the studio…"
	})] });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioHome, {});
}
function StudioHome() {
	const navigate = useNavigate();
	const [data, setData] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [handle, setHandle] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)("");
	async function refresh() {
		const result = await getStudio();
		if (!result.ok) {
			setError(result.error);
			return;
		}
		setData(result.data);
	}
	(0, import_react.useEffect)(() => {
		let cancel = false;
		getStudio().then((result) => {
			if (cancel) return;
			if (!result.ok) setError(result.error);
			else setData(result.data);
		}).catch((err) => {
			if (!cancel) setError(err instanceof Error ? err.message : "Could not open the studio.");
		});
		return () => {
			cancel = true;
		};
	}, []);
	async function claim(event) {
		event.preventDefault();
		setBusy("claim");
		setError("");
		try {
			const result = await claimHandle({ data: handle });
			if (!result.ok) setError(result.error);
			else await refresh();
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not claim that name.");
		} finally {
			setBusy("");
		}
	}
	async function addVersion() {
		if (!data || !data.profile) return;
		setBusy("create");
		setError("");
		try {
			const count = data.versions.length + 1;
			const result = await createVersion({ data: { title: `Issue ${count}` } });
			if (!result.ok) {
				setError(result.error);
				return;
			}
			await navigate({
				to: "/studio/$versionId",
				params: { versionId: result.data.id }
			});
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not create a version.");
		} finally {
			setBusy("");
		}
	}
	async function run(id, action) {
		setBusy(`${action}:${id}`);
		setError("");
		try {
			const result = action === "pub" || action === "unpub" ? await setVisibility({ data: {
				id,
				isPublic: action === "pub"
			} }) : action === "copy" ? await duplicateVersion({ data: id }) : await deleteVersion({ data: id });
			if (!result.ok) setError(result.error);
			else await refresh();
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not update that version.");
		} finally {
			setBusy("");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductBar, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "content",
		className: "shell py-12 md:py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-eyebrow text-pine uppercase",
				children: "Studio"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-section",
				children: "Your versions"
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-danger",
				children: error
			}) : null,
			!data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-muted",
				children: "Loading your issues…"
			}) : null,
			data && data.profile === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-8 max-w-md",
				onSubmit: (event) => void claim(event),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted",
						children: "Claim a public name. It becomes the front of your links, like /p/your-name. Letters, numbers, and single hyphens. 3–24 characters."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-4 grid gap-1 text-sm",
						children: ["Public name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: handle,
							onChange: (event) => setHandle(event.target.value),
							autoCapitalize: "off"
						})]
					}),
					handle && !parseHandle(handle) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "That name will not be accepted yet."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "btn-ink mt-4",
						disabled: busy === "claim",
						children: busy === "claim" ? "Claiming…" : "Claim name"
					})
				]
			}) : null,
			data && data.profile ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 max-w-2xl text-muted",
					children: [
						PLAN_LIMITS[data.profile.plan].label,
						" · ",
						data.profile.used,
						" of ",
						data.profile.versionLimit,
						" versions ·",
						" ",
						data.profile.publicCount,
						" public. Your index is",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/p/$handle",
							params: { handle: data.profile.handle },
							className: "text-ink underline-offset-4 hover:underline",
							children: ["/p/", data.profile.handle]
						}),
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap gap-3",
					children: [data.profile.used >= data.profile.versionLimit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/plans",
						className: "btn-ink",
						children: data.profile.plan === "free" ? "Upgrade to keep four" : "At the four-version limit"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn-ink",
						disabled: busy === "create",
						onClick: () => void addVersion(),
						children: busy === "create" ? "Creating…" : "New version"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/plans",
						className: "btn-line",
						children: "Plans"
					})]
				}),
				data.versions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-10 max-w-lg text-muted",
					children: "No versions yet. A version is the whole site — projects, about, skills, contact, and a bio. Start one, then publish it when you want it seen."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-10 divide-y divide-ink/15 border-y border-ink/15",
					children: data.versions.map((version) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "grid gap-4 py-5 md:grid-cols-[1fr_auto] md:items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl",
							children: version.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								version.isPublic ? "Public" : "Draft",
								version.name ? ` · ${version.name}` : "",
								" · /p/",
								data.profile && data.profile.handle,
								"/",
								version.slug
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/studio/$versionId",
									params: { versionId: version.id },
									className: "btn-line",
									children: "Edit"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn-line",
									disabled: busy === `pub:${version.id}` || busy === `unpub:${version.id}`,
									onClick: () => void run(version.id, version.isPublic ? "unpub" : "pub"),
									children: version.isPublic ? "Unpublish" : "Publish"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn-ghost",
									disabled: busy === `copy:${version.id}`,
									onClick: () => void run(version.id, "copy"),
									children: "Duplicate"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn-ghost",
									disabled: busy === `del:${version.id}`,
									onClick: () => void run(version.id, "del"),
									children: "Delete"
								})
							]
						})]
					}, version.id))
				})
			] }) : null
		]
	})] });
}
//#endregion
export { StudioGate as component };
