import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Z as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { p as setPlan } from "./router-Bgh4e7MR.mjs";
import { r as useCurrentUserState, t as ProductBar } from "./product-bar-DCcIP2rb.mjs";
import { t as PLAN_LIMITS } from "./portfolio-model-DyeoDMpX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/plans-CNSat436.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PlansPage() {
	const { user, isPending } = useCurrentUserState();
	const [message, setMessage] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(null);
	async function choose(plan) {
		setBusy(plan);
		setMessage("");
		try {
			const result = await setPlan({ data: plan });
			setMessage(result.ok ? `You are on ${PLAN_LIMITS[result.data.plan].label}.` : result.error);
		} catch (err) {
			setMessage(err instanceof Error ? err.message : "Could not change the plan.");
		} finally {
			setBusy(null);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductBar, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "content",
		className: "shell py-14 md:py-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-eyebrow text-pine uppercase",
				children: "Plans"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 max-w-3xl font-display text-section",
				children: "Two versions free. Four if you subscribe. Publish any of them."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-2xl text-muted",
				children: "A version is a full site: work with hover notes, about, skills, a contact form, and a bio page. Making one public does not hide the others. Visitors open the ones you mark public."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 grid gap-6 lg:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "border border-ink/15 p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-3xl",
								children: "Free"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: "$0"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-6 space-y-3 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [PLAN_LIMITS.free.versions, " versions in the studio"] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Publish whichever of them you want" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Each public version has its own link and bio" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Imprint credit in the footer" })
								]
							}),
							user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn-line mt-8",
								disabled: busy !== null,
								onClick: () => void choose("free"),
								children: busy === "free" ? "Switching…" : "Use Free"
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "border border-ink bg-ink p-6 text-paper",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-3xl",
								children: "Subscriber"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-paper/70",
								children: "No card in this studio"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-6 space-y-3 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [PLAN_LIMITS.subscriber.versions, " versions in the studio"] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Publish any combination, including all four" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Useful split: work, teaching, speaking, archive" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Switch back to Free after you are down to two" })
								]
							}),
							user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn-line on-ink mt-8",
								disabled: busy !== null,
								onClick: () => void choose("subscriber"),
								children: busy === "subscriber" ? "Switching…" : "Become a subscriber"
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "border border-ink/15 bg-wash p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium tracking-eyebrow text-pine uppercase",
								children: "Suggested, not for sale"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-2 font-display text-3xl",
								children: "Press"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-6 space-y-3 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "More than four versions" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "A custom domain on the public link" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Footer credit removed" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "One collaborator on the studio" })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-8 text-sm text-muted",
								children: "Not built yet. Subscriber is the highest plan you can turn on."
							})
						]
					})
				]
			}),
			isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-sm text-muted",
				children: "Checking the session…"
			}) : null,
			!isPending && !user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/login",
					className: "btn-ink",
					children: "Sign in to start on Free"
				})
			}) : null,
			message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 max-w-xl text-sm",
				children: message
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-16 max-w-2xl border-t border-ink/15 pt-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl",
						children: "How a version is used"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "mt-6 space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: "1. Write it."
							}), " Name, headline, projects, skills, about, and a bio."] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: "2. Keep another."
							}), " A hiring issue beside a personal one. The second stays a draft until you say otherwise."] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: "3. Publish the ones you mean."
							}), " Each public version has a link. If more than one is public, your name page lists them."] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-sm text-muted",
						children: "Turning on Subscriber does not charge a card. Billing is not connected, so the limit changes immediately and you can switch back."
					})
				]
			})
		]
	})] });
}
//#endregion
export { PlansPage as component };
