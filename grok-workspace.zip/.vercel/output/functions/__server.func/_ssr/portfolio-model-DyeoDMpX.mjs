//#region node_modules/.nitro/vite/services/ssr/assets/portfolio-model-DyeoDMpX.js
var PLAN_LIMITS = {
	free: {
		versions: 2,
		label: "Free",
		line: "Keep two versions. Publish either, or both."
	},
	subscriber: {
		versions: 4,
		label: "Subscriber",
		line: "Keep four versions. Publish whichever ones you want."
	}
};
var RESERVED = /* @__PURE__ */ new Set([
	"login",
	"studio",
	"sample",
	"plans",
	"api",
	"auth",
	"admin",
	"imprint",
	"www",
	"app",
	"public",
	"settings",
	"account",
	"pricing",
	"about",
	"p",
	"bio",
	"signup",
	"sign-in",
	"sign-up"
]);
function blankContent() {
	return {
		name: "",
		role: "",
		location: "",
		headline: "",
		deck: "",
		about: "",
		bio: "",
		now: [],
		timeline: [],
		skills: [],
		projects: [],
		contactNote: "",
		email: "",
		links: []
	};
}
function clip(value, max) {
	if (typeof value !== "string") return "";
	return value.trim().slice(0, max);
}
function parseHandle(raw) {
	const handle = raw.trim().toLowerCase();
	if (!/^[a-z0-9][a-z0-9-]{1,22}[a-z0-9]$/.test(handle)) return null;
	if (handle.includes("--")) return null;
	if (RESERVED.has(handle)) return null;
	return handle;
}
function parseSlug(raw) {
	const slug = raw.trim().toLowerCase();
	if (!/^[a-z0-9][a-z0-9-]{0,38}[a-z0-9]$/.test(slug) && !/^[a-z0-9]{2}$/.test(slug)) return null;
	if (slug.includes("--") || slug.length < 2 || slug.length > 40) return null;
	return slug;
}
function slugify(raw) {
	return parseSlug(raw.toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").replace(/-{2,}/g, "-").slice(0, 40).replace(/-+$/g, "")) ?? "issue";
}
function safeHref(raw) {
	const href = raw.trim();
	if (/^https?:\/\/[^\s]+$/i.test(href)) return href;
	if (/^mailto:[^\s@]+@[^\s@]+$/i.test(href)) return href;
	return null;
}
function isEmail(raw) {
	return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(raw.trim());
}
function paragraphs(text) {
	return text.split(/\n{2,}/).map((part) => part.trim()).filter(Boolean);
}
function categoriesOf(projects) {
	const seen = /* @__PURE__ */ new Set();
	const out = [];
	for (const project of projects) {
		const category = project.category || "General";
		if (seen.has(category)) continue;
		seen.add(category);
		out.push(category);
	}
	return out;
}
function normalizeContent(input) {
	const source = input && typeof input === "object" ? input : {};
	const projects = Array.isArray(source.projects) ? source.projects.slice(0, 12) : [];
	const skills = Array.isArray(source.skills) ? source.skills.slice(0, 6) : [];
	const timeline = Array.isArray(source.timeline) ? source.timeline.slice(0, 8) : [];
	const now = Array.isArray(source.now) ? source.now.slice(0, 6) : [];
	const links = Array.isArray(source.links) ? source.links.slice(0, 6) : [];
	return {
		name: clip(source.name, 80),
		role: clip(source.role, 80),
		location: clip(source.location, 80),
		headline: clip(source.headline, 160),
		deck: clip(source.deck, 320),
		about: clip(source.about, 1200),
		bio: clip(source.bio, 5e3),
		contactNote: clip(source.contactNote, 400),
		email: clip(source.email, 120),
		now: now.map((item) => clip(item, 120)).filter(Boolean),
		timeline: timeline.map((item) => {
			const row = item && typeof item === "object" ? item : {};
			const year = clip(row.year, 16);
			const text = clip(row.text, 160);
			if (!year && !text) return null;
			return {
				year,
				text
			};
		}).filter((item) => item !== null),
		skills: skills.map((item) => {
			const row = item && typeof item === "object" ? item : {};
			const group = clip(row.group, 40);
			const items = (Array.isArray(row.items) ? row.items.slice(0, 8) : []).map((skill) => {
				const skillRow = skill && typeof skill === "object" ? skill : {};
				const name = clip(skillRow.name, 48);
				const detail = clip(skillRow.detail, 80);
				if (!name) return null;
				return {
					name,
					detail
				};
			}).filter((skill) => skill !== null);
			if (!group || items.length === 0) return null;
			return {
				group,
				items
			};
		}).filter((group) => group !== null),
		projects: projects.map((item) => {
			const row = item && typeof item === "object" ? item : {};
			const title = clip(row.title, 80);
			if (!title) return null;
			return {
				title,
				year: clip(row.year, 12),
				category: clip(row.category, 32) || "General",
				role: clip(row.role, 80),
				summary: clip(row.summary, 280)
			};
		}).filter((project) => project !== null),
		links: links.map((item) => {
			const row = item && typeof item === "object" ? item : {};
			const label = clip(row.label, 40);
			const href = safeHref(clip(row.href, 200));
			if (!label || !href) return null;
			return {
				label,
				href
			};
		}).filter((link) => link !== null)
	};
}
function asPlan(value) {
	return value === "subscriber" ? "subscriber" : "free";
}
//#endregion
export { isEmail as a, parseHandle as c, categoriesOf as i, parseSlug as l, asPlan as n, normalizeContent as o, blankContent as r, paragraphs as s, PLAN_LIMITS as t, slugify as u };
