import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as ProductBar } from "./product-bar-DCcIP2rb.mjs";
import { n as IssueView } from "./issue-view-Cz2q8c-c.mjs";
import { t as specimen } from "./specimen-D78k8s0g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-rBwWNofN.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductBar, { notice: "Specimen issue below — not a member. Sign in to publish your own. Free keeps 2 versions. A subscriber keeps 4, and any of them can be public." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IssueView, {
		content: specimen,
		issueLabel: "Specimen",
		nav: { kind: "sample" },
		credit: "specimen"
	})] });
}
//#endregion
export { Home as component };
