import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as ProductBar } from "./product-bar-DCcIP2rb.mjs";
import { t as BioView } from "./issue-view-Cz2q8c-c.mjs";
import { t as specimen } from "./specimen-D78k8s0g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sample.bio-CtC_u5C1.js
var import_jsx_runtime = require_jsx_runtime();
function SampleBio() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductBar, { notice: "Specimen bio. Your versions get a bio page of their own." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BioView, {
		content: specimen,
		issueLabel: "Specimen",
		nav: { kind: "sample" },
		credit: "specimen"
	})] });
}
//#endregion
export { SampleBio as component };
