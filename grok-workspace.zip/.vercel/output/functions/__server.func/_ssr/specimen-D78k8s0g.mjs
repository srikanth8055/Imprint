//#region node_modules/.nitro/vite/services/ssr/assets/specimen-D78k8s0g.js
var specimen = {
	name: "Rowan Ellis",
	role: "Product engineer and editor",
	location: "Specimen issue",
	headline: "Interfaces with the patience of print.",
	deck: "This is a sample version, not a member. Sign in to write your own — work, a bio, and a public link for each one you choose to publish.",
	about: "A version is a whole site. The home page carries the work, a short about, the skills, and a note. The bio page is where the longer story sits.\n\nNothing here is a real person. Replace the lines when you start an issue of your own. Free accounts keep two versions. Subscribers keep four, and any of them can be public.",
	bio: "Rowan Ellis is a specimen: a stand-in so the type, the grid, and the hover notes can be read before you put your name on a version.\n\nThe practice this sample describes is small on purpose. Sequence first, then type, then the motion that should almost not be noticed. Code follows the order of the page, not the other way around.\n\nUse the studio to keep more than one of these. A hiring version and a personal one. A teaching site beside a client site. Publish whichever you want people to open, and leave the rest as drafts.",
	now: [
		"Showing how a public issue is set",
		"Leaving room for your own name",
		"Keeping drafts next to the live version"
	],
	timeline: [
		{
			year: "2018",
			text: "First pages, set too tightly, then opened up."
		},
		{
			year: "2021",
			text: "A product role. Fewer screens, clearer sentences."
		},
		{
			year: "2024",
			text: "Independent. One issue at a time."
		},
		{
			year: "2026",
			text: "This specimen, waiting to be replaced."
		}
	],
	skills: [{
		group: "Practice",
		items: [
			{
				name: "Editorial layout",
				detail: "Covers, columns, sequence"
			},
			{
				name: "Product interface",
				detail: "Flows a person can finish"
			},
			{
				name: "Writing",
				detail: "Notes that earn their length"
			}
		]
	}, {
		group: "Engineering",
		items: [
			{
				name: "TypeScript",
				detail: "Typed UI and small services"
			},
			{
				name: "React",
				detail: "Pages, not component museums"
			},
			{
				name: "Accessibility",
				detail: "Keyboard, names, contrast"
			}
		]
	}],
	projects: [
		{
			title: "Atelier",
			year: "2025",
			category: "Product",
			role: "Design and engineering",
			summary: "A publishing surface that treats the homepage like a printed cover — type first, chrome last."
		},
		{
			title: "Monsoon Ledger",
			year: "2025",
			category: "Product",
			role: "Product engineering",
			summary: "A ledger for irregular income: advances, retainers, and the months in between."
		},
		{
			title: "Field Notes",
			year: "2024",
			category: "Writing",
			role: "Editor",
			summary: "A reading journal for long essays, with margins wide enough to think in."
		},
		{
			title: "Archive Room",
			year: "2024",
			category: "Writing",
			role: "Research and design",
			summary: "Oral histories set as a slow reading room, not a feed."
		},
		{
			title: "Station 9",
			year: "2023",
			category: "Brand",
			role: "Identity",
			summary: "Wayfinding and menus for nine rooms that share one kitchen."
		},
		{
			title: "Kite",
			year: "2024",
			category: "Engineering",
			role: "Open source",
			summary: "A tiny timing library: one easing, readable durations, no carnival."
		}
	],
	contactNote: "The specimen does not receive mail. On your own version, add an address and visitors can copy a note to send you.",
	email: "hello@example.com",
	links: []
};
//#endregion
export { specimen as t };
