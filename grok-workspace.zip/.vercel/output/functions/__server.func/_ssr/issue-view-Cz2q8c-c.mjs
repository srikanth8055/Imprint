import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Z as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as isEmail, i as categoriesOf, s as paragraphs } from "./portfolio-model-DyeoDMpX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/issue-view-Cz2q8c-c.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function IssueView({ content, issueLabel, nav, credit }) {
	const categories = categoriesOf(content.projects);
	const [filter, setFilter] = (0, import_react.useState)("All");
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const visible = filter === "All" ? content.projects : content.projects.filter((project) => project.category === filter);
	const name = content.name || "Untitled";
	const headline = content.headline || "An issue without a headline yet.";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-screen flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-b border-ink/15",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "shell flex min-h-16 flex-wrap items-center justify-between gap-x-4 gap-y-2 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeLink, {
						nav,
						className: "font-display text-2xl tracking-tight",
						children: name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "flex flex-wrap items-center gap-x-4 gap-y-2 text-sm",
						"aria-label": "Issue",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#work",
								className: "underline-offset-4 hover:underline",
								children: "Work"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#about",
								className: "underline-offset-4 hover:underline",
								children: "About"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#skills",
								className: "underline-offset-4 hover:underline",
								children: "Skills"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#contact",
								className: "underline-offset-4 hover:underline",
								children: "Contact"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BioLink, {
								nav,
								className: "underline-offset-4 hover:underline",
								children: "Bio"
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				id: "content",
				className: "flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "shell grid items-end gap-10 py-14 md:grid-cols-12 md:py-20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "md:col-span-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-medium tracking-eyebrow text-pine uppercase",
									children: [issueLabel, content.location ? ` · ${content.location}` : ""]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "mt-4 font-display text-hero",
									children: headline
								}),
								content.deck ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-6 max-w-xl text-lg text-muted",
									children: content.deck
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8 flex flex-wrap gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "#work",
										className: "btn-ink",
										children: "View the work"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BioLink, {
										nav,
										className: "btn-line",
										children: "Read the bio"
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
							className: "border border-ink/15 p-6 md:col-span-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium tracking-eyebrow text-muted uppercase",
									children: "Masthead"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 font-display text-3xl",
									children: name
								}),
								content.role ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-muted",
									children: content.role
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-6 text-sm",
									children: [content.projects.length.toString().padStart(2, "0"), " pieces in this version"]
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "work",
						className: "border-t border-ink/15",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "shell py-14 md:py-20",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-end justify-between gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-section",
										children: "Selected work"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm text-muted tabular-nums",
										"aria-live": "polite",
										children: [visible.length.toString().padStart(2, "0"), " shown"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-6 flex flex-wrap gap-2",
									role: "group",
									"aria-label": "Filter projects",
									children: ["All", ...categories].map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "chip",
										"aria-pressed": filter === category,
										onClick: () => {
											setFilter(category);
											setOpenId(null);
										},
										children: category
									}, category))
								}),
								visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-10 max-w-md text-muted",
									children: "No pieces in this issue yet."
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-8 grid gap-8 md:grid-cols-2",
									children: visible.map((project, index) => {
										const feature = filter === "All" && index === 0;
										const absolute = content.projects.indexOf(project);
										const open = openId === absolute;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: feature ? "project-card is-feature md:col-span-2" : "project-card",
											"data-open": open ? "true" : "false",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "cover",
													children: project.summary ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														type: "button",
														className: "cover-hit",
														"aria-expanded": open,
														onClick: () => setOpenId(open ? null : absolute),
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoverArt, {
															title: project.title,
															index: String(absolute + 1).padStart(2, "0"),
															year: project.year,
															category: project.category,
															layout: absolute % 3
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "blurb",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-xs font-medium tracking-eyebrow uppercase",
																children: open ? "Close" : "Note"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "mt-2 block text-base",
																children: project.summary
															})]
														})]
													}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "cover-hit",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoverArt, {
															title: project.title,
															index: String(absolute + 1).padStart(2, "0"),
															year: project.year,
															category: project.category,
															layout: absolute % 3
														})
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "mt-4 flex items-baseline justify-between gap-4",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
														className: "font-display text-2xl",
														children: project.title
													}), project.year ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-sm text-muted tabular-nums",
														children: project.year
													}) : null]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "mt-1 text-sm text-muted",
													children: [project.category, project.role ? ` · ${project.role}` : ""]
												})
											]
										}, `${project.title}-${absolute}`);
									})
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "about",
						className: "border-t border-ink/15 bg-wash",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "shell grid gap-8 py-14 md:grid-cols-12 md:py-20",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-section md:col-span-4",
								children: "About"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "max-w-prose md:col-span-8",
								children: [paragraphs(content.about).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-muted",
									children: "This version has no about text yet."
								}) : paragraphs(content.about).map((paragraph) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 first:mt-0",
									children: paragraph
								}, paragraph.slice(0, 24))), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BioLink, {
									nav,
									className: "btn-line mt-8",
									children: "Full bio"
								})]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "skills",
						className: "border-t border-ink/15",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "shell py-14 md:py-20",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-section",
								children: "Skills"
							}), content.skills.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-6 text-muted",
								children: "No skills listed on this version."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-8 grid gap-10 md:grid-cols-2",
								children: content.skills.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-xs font-medium tracking-eyebrow text-pine uppercase",
									children: group.group
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
									className: "mt-4 divide-y divide-ink/15 border-y border-ink/15",
									children: group.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-1 py-3 sm:grid-cols-2 sm:gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: item.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "text-muted",
											children: item.detail
										})]
									}, item.name))
								})] }, group.group))
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactBlock, { content })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IssueFooter, {
				content,
				nav,
				credit,
				issueLabel
			})
		]
	});
}
function BioView({ content, issueLabel, nav, credit }) {
	const name = content.name || "Untitled";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-screen flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-b border-ink/15",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "shell flex min-h-16 flex-wrap items-center justify-between gap-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeLink, {
						nav,
						className: "font-display text-2xl",
						children: name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeLink, {
						nav,
						className: "text-sm underline-offset-4 hover:underline",
						children: "Back to the issue"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				id: "content",
				className: "shell flex-1 py-14 md:py-20",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs font-medium tracking-eyebrow text-pine uppercase",
						children: ["Bio · ", issueLabel]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-4 max-w-3xl font-display text-section",
						children: content.headline || name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-muted",
						children: [
							name,
							content.role ? ` · ${content.role}` : "",
							content.location ? ` · ${content.location}` : ""
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10 grid gap-12 lg:grid-cols-12",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
							className: "max-w-prose lg:col-span-7",
							children: paragraphs(content.bio).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted",
								children: "This version has no bio yet."
							}) : paragraphs(content.bio).map((paragraph) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 first:mt-0 text-lg",
								children: paragraph
							}, paragraph.slice(0, 32)))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
							className: "lg:col-span-5",
							children: [content.now.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-xs font-medium tracking-eyebrow text-pine uppercase",
								children: "Now"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 space-y-3",
								children: content.now.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "border-t border-ink/15 pt-3",
									children: item
								}, item))
							})] }) : null, content.timeline.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-10",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-xs font-medium tracking-eyebrow text-pine uppercase",
									children: "Then"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
									className: "mt-4",
									children: content.timeline.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "grid grid-cols-[4.5rem_1fr] gap-3 border-t border-ink/15 py-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm text-muted tabular-nums",
											children: entry.year
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: entry.text })]
									}, `${entry.year}-${entry.text}`))
								})]
							}) : null]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IssueFooter, {
				content,
				nav,
				credit,
				issueLabel
			})
		]
	});
}
function ContactBlock({ content }) {
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)("");
	const [errors, setErrors] = (0, import_react.useState)({});
	const [sent, setSent] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const listed = isEmail(content.email) ? content.email.trim() : "";
	function onSubmit(event) {
		event.preventDefault();
		const next = {};
		if (!name.trim()) next.name = "Add your name.";
		if (!isEmail(email)) next.email = "That email does not look complete.";
		if (message.trim().length < 12) next.message = "A sentence or two is enough.";
		setErrors(next);
		if (Object.keys(next).length > 0) return;
		setSent(true);
		setCopied(false);
	}
	async function copyNote() {
		const body = `From ${name.trim()} <${email.trim()}>\n\n${message.trim()}`;
		try {
			await navigator.clipboard.writeText(body);
			setCopied(true);
		} catch {
			setCopied(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "contact",
		className: "border-t border-ink/15 bg-ink text-paper",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "shell grid gap-10 py-14 md:grid-cols-12 md:py-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "md:col-span-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-section",
						children: "Write"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-sm text-paper/80",
						children: content.contactNote || "A short note is enough. Say what you are making."
					}),
					listed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-6 text-sm",
						children: [
							"Listed address:",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "underline underline-offset-4",
								href: `mailto:${listed}`,
								children: listed
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-sm text-paper/70",
						children: "This version does not list an email address."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "md:col-span-7",
				children: sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border border-paper/25 p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-3xl",
							children: [
								"Noted, ",
								name.trim(),
								"."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-paper/80",
							children: ["Nothing was emailed. ", listed ? `Copy the note and send it to ${listed}.` : "Copy it if you want to keep it."]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn-line on-ink",
								onClick: () => void copyNote(),
								children: copied ? "Copied" : "Copy note"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn-ghost text-paper",
								onClick: () => {
									setSent(false);
									setMessage("");
								},
								children: "Write another"
							})]
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "grid gap-5",
					onSubmit,
					noValidate: true,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1 text-sm",
							children: [
								"Name",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field on-ink",
									value: name,
									onChange: (event) => setName(event.target.value),
									autoComplete: "name"
								}),
								errors.name ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-wash",
									children: errors.name
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1 text-sm",
							children: [
								"Email",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field on-ink",
									value: email,
									onChange: (event) => setEmail(event.target.value),
									autoComplete: "email",
									inputMode: "email"
								}),
								errors.email ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-wash",
									children: errors.email
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1 text-sm",
							children: [
								"Note",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									className: "field on-ink",
									value: message,
									onChange: (event) => setMessage(event.target.value)
								}),
								errors.message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-wash",
									children: errors.message
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "btn-line on-ink w-fit",
							children: "Prepare note"
						})
					]
				})
			})]
		})
	});
}
function IssueFooter({ content, nav, credit, issueLabel }) {
	const name = content.name || "Untitled";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t border-ink/15",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "shell grid gap-10 py-12 md:grid-cols-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-4xl",
						children: name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 max-w-sm text-sm text-muted",
						children: [
							issueLabel,
							". ",
							content.role || "A public version on Imprint."
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-eyebrow text-muted uppercase",
						children: "In this issue"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-3 space-y-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLink, {
								nav,
								hash: "work",
								children: "Work"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLink, {
								nav,
								hash: "about",
								children: "About"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLink, {
								nav,
								hash: "skills",
								children: "Skills"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLink, {
								nav,
								hash: "contact",
								children: "Contact"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BioLink, {
								nav,
								className: "underline-offset-4 hover:underline",
								children: "Bio"
							}) })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-eyebrow text-muted uppercase",
						children: "Elsewhere"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-3 space-y-2 text-sm",
						children: [
							isEmail(content.email) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "break-all underline-offset-4 hover:underline",
								href: `mailto:${content.email.trim()}`,
								children: content.email.trim()
							}) }) : null,
							content.links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "break-all underline-offset-4 hover:underline",
								href: link.href,
								rel: "noreferrer",
								target: "_blank",
								children: link.label
							}) }, link.href)),
							content.links.length === 0 && !isEmail(content.email) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "text-muted",
								children: "No links listed."
							}) : null
						]
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "shell flex flex-wrap items-center justify-between gap-3 border-t border-ink/15 py-4 text-sm text-muted",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"© ",
				(/* @__PURE__ */ new Date()).getFullYear(),
				" ",
				name
			] }), credit === "specimen" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Specimen, not a member.",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/plans",
					className: "text-ink underline-offset-4 hover:underline",
					children: "See plans"
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Published with",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "text-ink underline-offset-4 hover:underline",
					children: "Imprint"
				})
			] })]
		})]
	});
}
function CoverArt({ title, index, year, category, layout }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col justify-between p-5",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between text-xs font-medium tracking-eyebrow text-muted uppercase",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: category }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: year || index })]
			}),
			layout === 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-7xl leading-none md:text-8xl",
				children: index
			}) : layout === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-4xl leading-none md:text-5xl",
				children: title.split(" ").map((word, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block",
					children: word
				}, `${word}-${index}`))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-5xl leading-display italic md:text-6xl",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: layout === 2 ? title : index
			})
		]
	});
}
function SectionLink({ nav, hash, children }) {
	const className = "underline-offset-4 hover:underline";
	if (nav.kind === "sample") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/",
		hash,
		className,
		children
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/p/$handle/$slug",
		params: {
			handle: nav.handle,
			slug: nav.slug
		},
		hash,
		className,
		children
	});
}
function HomeLink({ nav, className, children }) {
	if (nav.kind === "sample") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/",
		className,
		children
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/p/$handle/$slug",
		params: {
			handle: nav.handle,
			slug: nav.slug
		},
		className,
		children
	});
}
function BioLink({ nav, className, children }) {
	if (nav.kind === "sample") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/sample/bio",
		className,
		children
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/p/$handle/$slug/bio",
		params: {
			handle: nav.handle,
			slug: nav.slug
		},
		className,
		children
	});
}
//#endregion
export { IssueView as n, BioView as t };
