import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Z as require_react, b as Navigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as GROK_PROVIDERS } from "./server-Caazk8Hs.mjs";
import { r as signIn, t as authClient } from "./client-1vAx-gM_.mjs";
import { r as useCurrentUserState, t as ProductBar } from "./product-bar-DCcIP2rb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-BO1_1RR2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LoginPage() {
	const { user, isPending } = useCurrentUserState();
	const [mode, setMode] = (0, import_react.useState)("up");
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [done, setDone] = (0, import_react.useState)(false);
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductBar, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "shell py-20 text-muted",
		children: "Checking the session…"
	})] });
	if (user || done) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/studio" });
	async function onSubmit(event) {
		event.preventDefault();
		setError("");
		if (!email.includes("@") || password.length < 8) {
			setError("Use a real email and a password of at least 8 characters.");
			return;
		}
		if (mode === "up" && name.trim().length < 2) {
			setError("Add the name you want on the account.");
			return;
		}
		setBusy(true);
		try {
			const result = mode === "up" ? await authClient.signUp.email({
				email: email.trim(),
				password,
				name: name.trim()
			}) : await authClient.signIn.email({
				email: email.trim(),
				password
			});
			if (result.error) {
				setError(result.error.message || "Could not sign in.");
				setBusy(false);
				return;
			}
			await authClient.getSession();
			setDone(true);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not sign in.");
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductBar, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "content",
		className: "shell grid gap-12 py-14 md:grid-cols-2 md:py-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-eyebrow text-pine uppercase",
				children: "Account"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-section",
				children: "Your name, in the versions you choose to publish."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-md text-muted",
				children: "Free keeps two versions. A subscriber keeps four. Either plan can make any of those versions public."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/plans",
				className: "mt-6 inline-block text-sm underline-offset-4 hover:underline",
				children: "Compare plans"
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				role: "group",
				"aria-label": "Account mode",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "chip",
					"aria-pressed": mode === "up",
					onClick: () => setMode("up"),
					children: "Create account"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "chip",
					"aria-pressed": mode === "in",
					onClick: () => setMode("in"),
					children: "Sign in"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-6 grid gap-4",
				onSubmit: (event) => void onSubmit(event),
				noValidate: true,
				children: [
					mode === "up" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1 text-sm",
						children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: name,
							autoComplete: "name",
							onChange: (event) => setName(event.target.value)
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1 text-sm",
						children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: email,
							autoComplete: "email",
							inputMode: "email",
							onChange: (event) => setEmail(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1 text-sm",
						children: ["Password", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							type: "password",
							value: password,
							autoComplete: mode === "up" ? "new-password" : "current-password",
							onChange: (event) => setPassword(event.target.value)
						})]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-danger",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "btn-ink w-fit",
						disabled: busy,
						children: busy ? "Please wait…" : mode === "up" ? "Create account" : "Sign in"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-eyebrow text-muted uppercase",
					children: "Or continue with"
				}), GROK_PROVIDERS.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "btn-line",
					onClick: () => void signIn(provider.providerId, { callbackURL: "/studio" }),
					children: ["Continue with ", provider.label]
				}, provider.providerId))]
			})
		] })]
	})] });
}
//#endregion
export { LoginPage as component };
