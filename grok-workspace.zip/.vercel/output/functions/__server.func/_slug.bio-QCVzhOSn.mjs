import { C as require_jsx_runtime, y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as Route } from "./_ssr/router-Bgh4e7MR.mjs";
import { t as ProductBar } from "./_ssr/product-bar-DCcIP2rb.mjs";
import { t as BioView } from "./_ssr/issue-view-Cz2q8c-c.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug.bio-QCVzhOSn.js
var import_jsx_runtime = require_jsx_runtime();
function PublicBioPage() {
	const { handle, issue } = Route.useLoaderData();
	if (!issue) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductBar, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "shell py-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-section",
			children: "This bio is not public."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/p/$handle",
			params: { handle },
			className: "btn-line mt-6",
			children: "Public versions"
		})]
	})] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BioView, {
		content: issue.content,
		issueLabel: issue.title,
		nav: {
			kind: "member",
			handle,
			slug: issue.slug
		},
		credit: "member"
	});
}
//#endregion
export { PublicBioPage as component };
