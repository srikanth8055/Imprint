import { o as __toESM } from "./_runtime.mjs";
import { C as require_jsx_runtime, Z as require_react, x as useNavigate, y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { a as Route$5, c as deleteVersion, d as getVersion, f as saveVersion, m as setVisibility, u as getStudio } from "./_ssr/router-Bgh4e7MR.mjs";
import { n as RedirectToSignIn, r as useCurrentUserState, t as ProductBar } from "./_ssr/product-bar-DCcIP2rb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_versionId-iFqjAMYt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function VersionEditor({ version, handle }) {
	const navigate = useNavigate();
	const [title, setTitle] = (0, import_react.useState)(version.title);
	const [slug, setSlug] = (0, import_react.useState)(version.slug);
	const [content, setContent] = (0, import_react.useState)(version.content);
	const [isPublic, setIsPublic] = (0, import_react.useState)(version.isPublic);
	const [status, setStatus] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [confirmDelete, setConfirmDelete] = (0, import_react.useState)(false);
	function patch(partial) {
		setContent((current) => ({
			...current,
			...partial
		}));
	}
	async function persist(nextPublic = isPublic) {
		setBusy(true);
		setError("");
		setStatus("");
		try {
			const saved = await saveVersion({ data: {
				id: version.id,
				title,
				slug,
				content
			} });
			if (!saved.ok) {
				setError(saved.error);
				return;
			}
			setSlug(saved.data.slug);
			if (nextPublic !== isPublic) {
				const vis = await setVisibility({ data: {
					id: version.id,
					isPublic: nextPublic
				} });
				if (!vis.ok) {
					setError(vis.error);
					return;
				}
				setIsPublic(vis.data.isPublic);
			}
			setStatus(nextPublic ? "Saved and public." : "Saved as a draft.");
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not save.");
		} finally {
			setBusy(false);
		}
	}
	async function remove() {
		setBusy(true);
		setError("");
		try {
			const result = await deleteVersion({ data: version.id });
			if (!result.ok) {
				setError(result.error);
				setBusy(false);
				return;
			}
			await navigate({ to: "/studio" });
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not delete.");
			setBusy(false);
		}
	}
	const publicPath = `/p/${handle}/${slug || version.slug}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "shell py-10",
		onSubmit: (event) => {
			event.preventDefault();
			persist();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/studio",
						className: "text-sm underline-offset-4 hover:underline",
						children: "All versions"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-section",
						children: "Edit version"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted",
						children: [
							isPublic ? "Public" : "Draft",
							" · ",
							publicPath
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "btn-ink",
						disabled: busy,
						children: busy ? "Saving…" : "Save"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn-line",
						disabled: busy,
						onClick: () => void persist(!isPublic),
						children: isPublic ? "Unpublish" : "Publish"
					})]
				})]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-danger",
				children: error
			}) : null,
			status ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-pine",
				children: status
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "mt-10 grid gap-4 border-0 p-0 md:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "font-display text-2xl",
						children: "This version"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-4 grid gap-1 text-sm",
						children: ["Version name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: title,
							maxLength: 60,
							onChange: (event) => setTitle(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-4 grid gap-1 text-sm",
						children: ["Public slug", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: slug,
							maxLength: 40,
							onChange: (event) => setSlug(event.target.value.toLowerCase())
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "mt-12 grid gap-4 border-0 p-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "font-display text-2xl",
						children: "Masthead"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-4 md:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Name",
								value: content.name,
								onChange: (name) => patch({ name }),
								maxLength: 80
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Role",
								value: content.role,
								onChange: (role) => patch({ role }),
								maxLength: 80
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Location",
								value: content.location,
								onChange: (location) => patch({ location }),
								maxLength: 80
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Email",
								value: content.email,
								onChange: (email) => patch({ email }),
								maxLength: 120
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Headline",
						value: content.headline,
						onChange: (headline) => patch({ headline }),
						maxLength: 160
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
						label: "Deck",
						value: content.deck,
						onChange: (deck) => patch({ deck }),
						maxLength: 320
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "mt-12 grid gap-4 border-0 p-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "font-display text-2xl",
						children: "About and bio"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
						label: "About, on the home page",
						value: content.about,
						onChange: (about) => patch({ about }),
						maxLength: 1200
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
						label: "Bio page",
						value: content.bio,
						onChange: (bio) => patch({ bio }),
						maxLength: 5e3
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lines, {
						label: "Now — one line each",
						rows: content.now,
						onChange: (now) => patch({ now }),
						placeholder: "What you are doing"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timeline, {
						rows: content.timeline,
						onChange: (timeline) => patch({ timeline })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Projects, {
				rows: content.projects,
				onChange: (projects) => patch({ projects })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skills, {
				rows: content.skills,
				onChange: (skills) => patch({ skills })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "mt-12 grid gap-4 border-0 p-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "font-display text-2xl",
						children: "Contact"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
						label: "Note above the form",
						value: content.contactNote,
						onChange: (contactNote) => patch({ contactNote }),
						maxLength: 400
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "The form does not send mail. Visitors can copy a note. If you list an email, they are pointed at it."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Links, {
						rows: content.links,
						onChange: (links) => patch({ links })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 flex flex-wrap items-center gap-3 border-t border-ink/15 pt-6",
				children: [isPublic ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "btn-line",
					href: publicPath,
					children: "Open public page"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Publish to open the public page."
				}), confirmDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: "Delete this version?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn-ink",
						disabled: busy,
						onClick: () => void remove(),
						children: "Delete"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn-ghost",
						onClick: () => setConfirmDelete(false),
						children: "Cancel"
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn-ghost",
					onClick: () => setConfirmDelete(true),
					children: "Delete version"
				})]
			})
		]
	});
}
function Field({ label, value, onChange, maxLength }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "grid gap-1 text-sm",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "field",
			value,
			maxLength,
			onChange: (event) => onChange(event.target.value)
		})]
	});
}
function Area({ label, value, onChange, maxLength }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "grid gap-1 text-sm",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			className: "field",
			value,
			maxLength,
			onChange: (event) => onChange(event.target.value)
		})]
	});
}
function Lines({ label, rows, onChange, placeholder }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm",
			children: label
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 grid gap-2",
			children: rows.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					value: row,
					placeholder,
					maxLength: 120,
					onChange: (event) => onChange(rows.map((item, i) => i === index ? event.target.value : item))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn-ghost",
					onClick: () => onChange(rows.filter((_, i) => i !== index)),
					children: "Remove"
				})]
			}, index))
		}),
		rows.length < 6 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "btn-line mt-3",
			onClick: () => onChange([...rows, ""]),
			children: "Add line"
		}) : null
	] });
}
function Timeline({ rows, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm",
			children: "Timeline"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 grid gap-3",
			children: rows.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 sm:grid-cols-[6rem_1fr_auto]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: row.year,
						placeholder: "Year",
						maxLength: 16,
						onChange: (event) => onChange(rows.map((item, i) => i === index ? {
							...item,
							year: event.target.value
						} : item))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: row.text,
						placeholder: "What happened",
						maxLength: 160,
						onChange: (event) => onChange(rows.map((item, i) => i === index ? {
							...item,
							text: event.target.value
						} : item))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn-ghost",
						onClick: () => onChange(rows.filter((_, i) => i !== index)),
						children: "Remove"
					})
				]
			}, index))
		}),
		rows.length < 8 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "btn-line mt-3",
			onClick: () => onChange([...rows, {
				year: "",
				text: ""
			}]),
			children: "Add year"
		}) : null
	] });
}
function Projects({ rows, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
		className: "mt-12 border-0 p-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
				className: "font-display text-2xl",
				children: "Work"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-xl text-sm text-muted",
				children: "The short summary is what appears when someone hovers a project, or taps Note."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid gap-6",
				children: rows.map((project, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 border border-ink/15 p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 md:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Title",
									value: project.title,
									maxLength: 80,
									onChange: (title) => updateProject(rows, index, { title }, onChange)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Year",
									value: project.year,
									maxLength: 12,
									onChange: (year) => updateProject(rows, index, { year }, onChange)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Category",
									value: project.category,
									maxLength: 32,
									onChange: (category) => updateProject(rows, index, { category }, onChange)
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Role",
							value: project.role,
							maxLength: 80,
							onChange: (role) => updateProject(rows, index, { role }, onChange)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
							label: "Hover note",
							value: project.summary,
							maxLength: 280,
							onChange: (summary) => updateProject(rows, index, { summary }, onChange)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn-ghost w-fit",
							onClick: () => onChange(rows.filter((_, i) => i !== index)),
							children: "Remove project"
						})
					]
				}, index))
			}),
			rows.length < 12 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn-line mt-4",
				onClick: () => onChange([...rows, {
					title: "",
					year: "",
					category: "",
					role: "",
					summary: ""
				}]),
				children: "Add project"
			}) : null
		]
	});
}
function updateProject(rows, index, partial, onChange) {
	onChange(rows.map((row, i) => i === index ? {
		...row,
		...partial
	} : row));
}
function Skills({ rows, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
		className: "mt-12 border-0 p-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
				className: "font-display text-2xl",
				children: "Skills"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid gap-6",
				children: rows.map((group, groupIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border border-ink/15 p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Group",
							value: group.group,
							maxLength: 40,
							onChange: (name) => onChange(rows.map((row, i) => i === groupIndex ? {
								...row,
								group: name
							} : row))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 grid gap-3",
							children: group.items.map((item, itemIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2 md:grid-cols-[1fr_1fr_auto]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "field",
										value: item.name,
										placeholder: "Skill",
										maxLength: 48,
										onChange: (event) => onChange(rows.map((row, i) => i === groupIndex ? {
											...row,
											items: row.items.map((skill, j) => j === itemIndex ? {
												...skill,
												name: event.target.value
											} : skill)
										} : row))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "field",
										value: item.detail,
										placeholder: "Detail",
										maxLength: 80,
										onChange: (event) => onChange(rows.map((row, i) => i === groupIndex ? {
											...row,
											items: row.items.map((skill, j) => j === itemIndex ? {
												...skill,
												detail: event.target.value
											} : skill)
										} : row))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "btn-ghost",
										onClick: () => onChange(rows.map((row, i) => i === groupIndex ? {
											...row,
											items: row.items.filter((_, j) => j !== itemIndex)
										} : row)),
										children: "Remove"
									})
								]
							}, itemIndex))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [group.items.length < 8 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn-line",
								onClick: () => onChange(rows.map((row, i) => i === groupIndex ? {
									...row,
									items: [...row.items, {
										name: "",
										detail: ""
									}]
								} : row)),
								children: "Add skill"
							}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn-ghost",
								onClick: () => onChange(rows.filter((_, i) => i !== groupIndex)),
								children: "Remove group"
							})]
						})
					]
				}, groupIndex))
			}),
			rows.length < 6 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn-line mt-4",
				onClick: () => onChange([...rows, {
					group: "",
					items: [{
						name: "",
						detail: ""
					}]
				}]),
				children: "Add group"
			}) : null
		]
	});
}
function Links({ rows, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm",
			children: "Links — https only"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 grid gap-3",
			children: rows.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 md:grid-cols-[10rem_1fr_auto]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: row.label,
						placeholder: "Label",
						maxLength: 40,
						onChange: (event) => onChange(rows.map((item, i) => i === index ? {
							...item,
							label: event.target.value
						} : item))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: row.href,
						placeholder: "https://",
						maxLength: 200,
						onChange: (event) => onChange(rows.map((item, i) => i === index ? {
							...item,
							href: event.target.value
						} : item))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn-ghost",
						onClick: () => onChange(rows.filter((_, i) => i !== index)),
						children: "Remove"
					})
				]
			}, index))
		}),
		rows.length < 6 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "btn-line mt-3",
			onClick: () => onChange([...rows, {
				label: "",
				href: ""
			}]),
			children: "Add link"
		}) : null
	] });
}
function EditorGate() {
	const { user, isPending } = useCurrentUserState();
	const { versionId } = Route$5.useParams();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductBar, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "shell py-20 text-muted",
		children: "Opening the version…"
	})] });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditorBody, { versionId });
}
function EditorBody({ versionId }) {
	const [version, setVersion] = (0, import_react.useState)(null);
	const [handle, setHandle] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		let cancel = false;
		Promise.all([getVersion({ data: versionId }), getStudio()]).then(([detail, studio]) => {
			if (cancel) return;
			if (!detail.ok) {
				setError(detail.error);
				return;
			}
			if (!studio.ok || studio.data.profile === null) {
				setError("Claim a public name before editing.");
				return;
			}
			setVersion(detail.data);
			setHandle(studio.data.profile.handle);
		}).catch((err) => {
			if (!cancel) setError(err instanceof Error ? err.message : "Could not load this version.");
		});
		return () => {
			cancel = true;
		};
	}, [versionId]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductBar, {}),
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "shell py-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: error }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/studio",
				className: "btn-line mt-6",
				children: "Back to the studio"
			})]
		}) : null,
		!error && !version ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "shell py-16 text-muted",
			children: "Loading this version…"
		}) : null,
		version && handle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VersionEditor, {
			version,
			handle
		}) : null
	] });
}
//#endregion
export { EditorGate as component };
