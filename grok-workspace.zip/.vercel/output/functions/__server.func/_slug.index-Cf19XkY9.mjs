import { C as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { r as Route$1 } from "./_ssr/router-Bgh4e7MR.mjs";
import { t as ProductBar } from "./_ssr/product-bar-DCcIP2rb.mjs";
import { n as IssueView } from "./_ssr/issue-view-Cz2q8c-c.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug.index-Cf19XkY9.js
var import_jsx_runtime = require_jsx_runtime();
function PublicIssuePage() {
	const { handle, issue } = Route$1.useLoaderData();
	if (!issue) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductBar, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "shell py-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-section",
			children: "This version is not public."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-muted",
			children: "It may be a draft, or the address is wrong."
		})]
	})] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IssueView, {
		content: issue.content,
		issueLabel: issue.title,
		nav: {
			kind: "member",
			handle,
			slug: issue.slug
		},
		credit: "member"
	});
}
//#endregion
export { PublicIssuePage as component };
