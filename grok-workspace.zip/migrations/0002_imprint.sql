create table if not exists profiles (
  user_id text primary key,
  handle text not null unique,
  plan text not null default 'free' check (plan in ('free', 'subscriber')),
  created_at timestamptz not null default now()
);

create table if not exists versions (
  id text primary key,
  user_id text not null references profiles (user_id) on delete cascade,
  slug text not null,
  title text not null,
  is_public boolean not null default false,
  content jsonb not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, slug)
);

create index if not exists versions_user_idx on versions (user_id);
