create table if not exists media (
  id text primary key,
  user_id text not null references profiles (user_id) on delete cascade,
  kind text not null check (kind in ('photo', 'short')),
  mime text not null,
  bytes integer not null check (bytes > 0 and bytes <= 8388608),
  data bytea not null,
  ready boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists media_user_idx on media (user_id);
