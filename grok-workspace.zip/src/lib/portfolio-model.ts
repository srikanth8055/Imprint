export type PlanId = "free" | "subscriber";

export type ProjectMedia = {
  id: string;
  kind: "photo" | "short";
};

export type Project = {
  title: string;
  year: string;
  category: string;
  role: string;
  summary: string;
  media: ProjectMedia[];
};

export type SkillGroup = {
  group: string;
  items: { name: string; detail: string }[];
};

export type TimelineEntry = { year: string; text: string };
export type OutLink = { label: string; href: string };

export type PortfolioContent = {
  name: string;
  role: string;
  location: string;
  headline: string;
  deck: string;
  about: string;
  bio: string;
  now: string[];
  timeline: TimelineEntry[];
  skills: SkillGroup[];
  projects: Project[];
  contactNote: string;
  email: string;
  links: OutLink[];
};

export type VersionSummary = {
  id: string;
  slug: string;
  title: string;
  isPublic: boolean;
  name: string;
  updatedAt: string;
};

export type VersionDetail = VersionSummary & { content: PortfolioContent };

export type PublicCard = {
  slug: string;
  title: string;
  name: string;
  role: string;
  headline: string;
};

export type PublicIssue = {
  slug: string;
  title: string;
  updatedAt: string;
  content: PortfolioContent;
};

export const MEDIA = {
  storageBytes: 40 * 1024 * 1024,
  photoMaxBytes: 800 * 1024,
  shortMaxBytes: 8 * 1024 * 1024,
  shortMaxSeconds: 30,
  photosPerProject: 3,
  shortsPerProject: 1,
  chunkBytes: 700_000,
};

export const PLAN_LIMITS: Record<PlanId, { versions: number; storageBytes: number; label: string; line: string }> = {
  free: {
    versions: 2,
    storageBytes: 0,
    label: "Free",
    line: "Keep two versions. Publish either, or both.",
  },
  subscriber: {
    versions: 4,
    storageBytes: MEDIA.storageBytes,
    label: "Subscriber",
    line: "Keep four versions, with 40 MB for photos and shorts.",
  },
};

const RESERVED = new Set([
  "login",
  "studio",
  "sample",
  "plans",
  "api",
  "auth",
  "admin",
  "imprint",
  "www",
  "app",
  "public",
  "settings",
  "account",
  "pricing",
  "about",
  "p",
  "bio",
  "signup",
  "sign-in",
  "sign-up",
]);

export function blankContent(): PortfolioContent {
  return {
    name: "",
    role: "",
    location: "",
    headline: "",
    deck: "",
    about: "",
    bio: "",
    now: [],
    timeline: [],
    skills: [],
    projects: [],
    contactNote: "",
    email: "",
    links: [],
  };
}

function clip(value: unknown, max: number): string {
  if (typeof value !== "string") return "";
  return value.trim().slice(0, max);
}

export function parseHandle(raw: string): string | null {
  const handle = raw.trim().toLowerCase();
  if (!/^[a-z0-9][a-z0-9-]{1,22}[a-z0-9]$/.test(handle)) return null;
  if (handle.includes("--")) return null;
  if (RESERVED.has(handle)) return null;
  return handle;
}

export function slugify(raw: string): string {
  const slug = raw
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 40)
    .replace(/-+$/g, "");
  return slug.length >= 2 ? slug : "issue";
}

export function parseSlug(raw: string): string | null {
  const slug = raw.trim().toLowerCase();
  if (slug.length < 2 || slug.length > 40) return null;
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug)) return null;
  return slug;
}

export function safeHref(raw: string): string | null {
  const href = raw.trim();
  if (/^https?:\/\/[^\s]+$/i.test(href)) return href;
  if (/^mailto:[^\s@]+@[^\s@]+$/i.test(href)) return href;
  return null;
}

export function isEmail(raw: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(raw.trim());
}

export function paragraphs(text: string): string[] {
  return text
    .split(/\n{2,}/)
    .map((part) => part.trim())
    .filter(Boolean);
}

export function categoriesOf(projects: Project[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const project of projects) {
    const category = project.category || "General";
    if (seen.has(category)) continue;
    seen.add(category);
    out.push(category);
  }
  return out;
}

export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 MB";
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  const mb = bytes / (1024 * 1024);
  return `${mb >= 10 ? Math.round(mb).toString() : mb.toFixed(1)} MB`;
}

const MEDIA_ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export function isMediaId(value: string): boolean {
  return MEDIA_ID.test(value);
}

function parseMedia(value: unknown): ProjectMedia[] {
  if (!Array.isArray(value)) return [];
  const out: ProjectMedia[] = [];
  let photos = 0;
  let shorts = 0;
  for (const item of value) {
    if (!item || typeof item !== "object") continue;
    const row = item as Record<string, unknown>;
    const id = typeof row.id === "string" ? row.id.trim().toLowerCase() : "";
    const kind = row.kind === "short" ? "short" : row.kind === "photo" ? "photo" : null;
    if (!kind || !MEDIA_ID.test(id)) continue;
    if (kind === "photo") {
      if (photos >= MEDIA.photosPerProject) continue;
      photos += 1;
    } else {
      if (shorts >= MEDIA.shortsPerProject) continue;
      shorts += 1;
    }
    out.push({ id, kind });
  }
  return out;
}

export function normalizeContent(input: unknown): PortfolioContent {
  const source = input && typeof input === "object" ? (input as Record<string, unknown>) : {};
  const projects = Array.isArray(source.projects) ? source.projects.slice(0, 12) : [];
  const skills = Array.isArray(source.skills) ? source.skills.slice(0, 6) : [];
  const timeline = Array.isArray(source.timeline) ? source.timeline.slice(0, 8) : [];
  const now = Array.isArray(source.now) ? source.now.slice(0, 6) : [];
  const links = Array.isArray(source.links) ? source.links.slice(0, 6) : [];

  return {
    name: clip(source.name, 80),
    role: clip(source.role, 80),
    location: clip(source.location, 80),
    headline: clip(source.headline, 160),
    deck: clip(source.deck, 320),
    about: clip(source.about, 1200),
    bio: clip(source.bio, 5000),
    contactNote: clip(source.contactNote, 400),
    email: clip(source.email, 120),
    now: now.map((item) => clip(item, 120)).filter(Boolean),
    timeline: timeline
      .map((item) => {
        const row = item && typeof item === "object" ? (item as Record<string, unknown>) : {};
        const year = clip(row.year, 16);
        const text = clip(row.text, 160);
        if (!year && !text) return null;
        return { year, text };
      })
      .filter((item): item is TimelineEntry => item !== null),
    skills: skills
      .map((item) => {
        const row = item && typeof item === "object" ? (item as Record<string, unknown>) : {};
        const group = clip(row.group, 40);
        const rawItems = Array.isArray(row.items) ? row.items.slice(0, 8) : [];
        const items = rawItems
          .map((skill) => {
            const skillRow = skill && typeof skill === "object" ? (skill as Record<string, unknown>) : {};
            const name = clip(skillRow.name, 48);
            const detail = clip(skillRow.detail, 80);
            if (!name) return null;
            return { name, detail };
          })
          .filter((skill): skill is { name: string; detail: string } => skill !== null);
        if (!group || items.length === 0) return null;
        return { group, items };
      })
      .filter((group): group is SkillGroup => group !== null),
    projects: projects
      .map((item) => {
        const row = item && typeof item === "object" ? (item as Record<string, unknown>) : {};
        const title = clip(row.title, 80);
        if (!title) return null;
        return {
          title,
          year: clip(row.year, 12),
          category: clip(row.category, 32) || "General",
          role: clip(row.role, 80),
          summary: clip(row.summary, 280),
          media: parseMedia(row.media),
        };
      })
      .filter((project): project is Project => project !== null),
    links: links
      .map((item) => {
        const row = item && typeof item === "object" ? (item as Record<string, unknown>) : {};
        const label = clip(row.label, 40);
        const href = safeHref(clip(row.href, 200));
        if (!label || !href) return null;
        return { label, href };
      })
      .filter((link): link is OutLink => link !== null),
  };
}

export function asPlan(value: unknown): PlanId {
  return value === "subscriber" ? "subscriber" : "free";
}
