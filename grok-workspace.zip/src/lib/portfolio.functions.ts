import { createServerFn } from "@tanstack/react-start";
import { getSql, type Sql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import {
  MEDIA,
  PLAN_LIMITS,
  asPlan,
  blankContent,
  isMediaId,
  normalizeContent,
  parseHandle,
  parseSlug,
  slugify,
  type PlanId,
  type PortfolioContent,
  type PublicCard,
  type PublicIssue,
  type VersionDetail,
  type VersionSummary,
} from "@/lib/portfolio-model";

type Result<T> = { ok: true; data: T } | { ok: false; error: string };

export type StudioData =
  | { profile: null }
  | {
      profile: {
        handle: string;
        plan: PlanId;
        versionLimit: number;
        used: number;
        publicCount: number;
        storageUsed: number;
        storageLimit: number;
      };
      versions: VersionSummary[];
    };

function fail(error: string): Result<never> {
  return { ok: false, error };
}

function isUnique(err: unknown): boolean {
  if (typeof err !== "object" || err === null) return false;
  const code = "code" in err ? String((err as { code?: unknown }).code) : "";
  if (code === "23505") return true;
  return String(err).toLowerCase().includes("unique");
}

function readContent(value: unknown): PortfolioContent {
  try {
    const parsed = typeof value === "string" ? JSON.parse(value) : value;
    return normalizeContent(parsed);
  } catch {
    return blankContent();
  }
}

function asBool(value: unknown): boolean {
  return value === true || value === "t" || value === "true" || value === 1;
}

function asText(value: unknown): string {
  return value == null ? "" : String(value);
}

function asNumber(value: unknown): number {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "bigint") return Number(value);
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

function mediaIdsOf(content: PortfolioContent): string[] {
  return content.projects.flatMap((project) => (project.media ?? []).map((item) => item.id));
}

async function storageOf(sql: Sql, userId: string): Promise<number> {
  const rows = await sql<{ used: unknown }>`
    select coalesce(sum(bytes), 0) as used from media where user_id = ${userId}
  `;
  return asNumber(rows[0]?.used);
}

async function pruneMedia(sql: Sql, userId: string): Promise<void> {
  await sql`
    delete from media
    where user_id = ${userId}
      and ready = false
      and created_at < now() - interval '15 minutes'
  `;
  const rows = await sql<{ content: unknown }>`select content from versions where user_id = ${userId}`;
  const keep = new Set<string>();
  for (const row of rows) {
    for (const id of mediaIdsOf(readContent(row.content))) keep.add(id);
  }
  const owned = await sql<{ id: string }>`select id from media where user_id = ${userId} and ready = true`;
  for (const row of owned) {
    if (!keep.has(row.id)) await sql`delete from media where id = ${row.id} and user_id = ${userId}`;
  }
}

function sniff(bytes: Uint8Array): { kind: "photo" | "short"; mime: string } | null {
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) {
    return { kind: "photo", mime: "image/jpeg" };
  }
  if (bytes.length >= 4 && bytes[0] === 0x1a && bytes[1] === 0x45 && bytes[2] === 0xdf && bytes[3] === 0xa3) {
    return { kind: "short", mime: "video/webm" };
  }
  const head = Buffer.from(bytes.subarray(0, Math.min(bytes.length, 32))).toString("latin1");
  if (head.includes("ftyp")) return { kind: "short", mime: "video/mp4" };
  return null;
}

function toBytes(value: unknown): Uint8Array | null {
  if (value instanceof Uint8Array) return value;
  if (typeof Buffer !== "undefined" && Buffer.isBuffer(value)) return new Uint8Array(value);
  if (value instanceof ArrayBuffer) return new Uint8Array(value);
  if (typeof value === "string" && value.startsWith("\\x")) {
    const hex = value.slice(2);
    if (hex.length % 2 !== 0) return null;
    const out = new Uint8Array(hex.length / 2);
    for (let i = 0; i < out.length; i += 1) out[i] = Number.parseInt(hex.slice(i * 2, i * 2 + 2), 16);
    return out;
  }
  return null;
}

function decodeChunk(dataBase64: string): Uint8Array | null {
  if (typeof dataBase64 !== "string" || dataBase64.length === 0 || dataBase64.length > 1_000_000) return null;
  const buf = Buffer.from(dataBase64, "base64");
  if (buf.byteLength === 0 || buf.byteLength > MEDIA.chunkBytes) return null;
  return new Uint8Array(buf);
}

async function limitFor(sql: Sql, userId: string): Promise<{ plan: PlanId; versions: number } | null> {
  const rows = await sql<{ plan: string }>`select plan from profiles where user_id = ${userId}`;
  if (!rows[0]) return null;
  const plan = asPlan(rows[0].plan);
  return { plan, versions: PLAN_LIMITS[plan].versions };
}

async function freeSlug(sql: Sql, userId: string, base: string): Promise<string> {
  const root = parseSlug(base) ?? "issue";
  let candidate = root;
  for (let n = 2; n < 30; n += 1) {
    const taken = await sql`select 1 as ok from versions where user_id = ${userId} and slug = ${candidate}`;
    if (taken.length === 0) return candidate;
    const stem = root.replace(/-\d+$/, "").slice(0, 36).replace(/-+$/g, "") || "issue";
    candidate = parseSlug(`${stem}-${n}`) ?? `issue-${n}`;
  }
  return `issue-${Date.now().toString(36)}`;
}

export const getStudio = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Result<StudioData>> => {
    const sql = await getSql();
    const profiles = await sql<{ handle: string; plan: string }>`
      select handle, plan from profiles where user_id = ${context.userId}
    `;
    if (!profiles[0]) return { ok: true, data: { profile: null } };
    const plan = asPlan(profiles[0].plan);
    await sql`
      delete from media
      where user_id = ${context.userId}
        and ready = false
        and created_at < now() - interval '15 minutes'
    `;
    const usedStorage = await storageOf(sql, context.userId);
    const versions = await sql<{
      id: string;
      slug: string;
      title: string;
      is_public: unknown;
      name: string | null;
      updated_at: unknown;
    }>`
      select id, slug, title, is_public, content->>'name' as name, updated_at::text as updated_at
      from versions
      where user_id = ${context.userId}
      order by updated_at desc
    `;
    const mapped: VersionSummary[] = versions.map((row) => ({
      id: row.id,
      slug: row.slug,
      title: row.title,
      isPublic: asBool(row.is_public),
      name: asText(row.name),
      updatedAt: asText(row.updated_at),
    }));
    return {
      ok: true,
      data: {
        profile: {
          handle: profiles[0].handle,
          plan,
          versionLimit: PLAN_LIMITS[plan].versions,
          used: mapped.length,
          publicCount: mapped.filter((row) => row.isPublic).length,
          storageUsed: usedStorage,
          storageLimit: PLAN_LIMITS[plan].storageBytes,
        },
        versions: mapped,
      },
    };
  });

export const claimHandle = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((handle: string) => handle)
  .handler(async ({ context, data }): Promise<Result<{ handle: string }>> => {
    const handle = parseHandle(data);
    if (!handle) {
      return fail("Use 3–24 letters, numbers, or single hyphens. Some names are reserved.");
    }
    const sql = await getSql();
    try {
      await sql`insert into profiles (user_id, handle) values (${context.userId}, ${handle})`;
    } catch (err) {
      if (!isUnique(err)) throw err;
      const mine = await sql`select 1 as ok from profiles where user_id = ${context.userId}`;
      if (mine.length) return fail("You already claimed a public name.");
      return fail("That public name is taken.");
    }
    return { ok: true, data: { handle } };
  });

export const createVersion = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { title: string }) => input)
  .handler(async ({ context, data }): Promise<Result<{ id: string }>> => {
    const title = data.title.trim().slice(0, 60) || "Untitled issue";
    const sql = await getSql();
    const plan = await limitFor(sql, context.userId);
    if (!plan) return fail("Claim a public name before you add a version.");
    const id = crypto.randomUUID();
    const slug = await freeSlug(sql, context.userId, slugify(title));
    const content = JSON.stringify(blankContent());
    try {
      const rows = await sql<{ id: string }>`
        insert into versions (id, user_id, slug, title, is_public, content)
        select ${id}, ${context.userId}, ${slug}, ${title}, false, ${content}::jsonb
        where (select count(*) from versions where user_id = ${context.userId}) < ${plan.versions}
        returning id
      `;
      if (!rows[0]) {
        return fail(
          plan.plan === "free"
            ? "Free keeps two versions. Become a subscriber to keep four."
            : "A subscriber keeps four versions. Remove one before adding another.",
        );
      }
      return { ok: true, data: { id: rows[0].id } };
    } catch (err) {
      if (isUnique(err)) return fail("That address is already used. Try again.");
      throw err;
    }
  });

export const getVersion = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((id: string) => id)
  .handler(async ({ context, data }): Promise<Result<VersionDetail>> => {
    const sql = await getSql();
    const rows = await sql<{
      id: string;
      slug: string;
      title: string;
      is_public: unknown;
      content: unknown;
      updated_at: unknown;
      name: string | null;
    }>`
      select id, slug, title, is_public, content, updated_at::text as updated_at, content->>'name' as name
      from versions
      where id = ${data} and user_id = ${context.userId}
    `;
    const row = rows[0];
    if (!row) return fail("That version is not in your studio.");
    const content = readContent(row.content);
    return {
      ok: true,
      data: {
        id: row.id,
        slug: row.slug,
        title: row.title,
        isPublic: asBool(row.is_public),
        name: content.name,
        updatedAt: asText(row.updated_at),
        content,
      },
    };
  });

export const saveVersion = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: string; title: string; slug: string; content: PortfolioContent }) => input)
  .handler(async ({ context, data }): Promise<Result<{ slug: string; storageUsed: number }>> => {
    const title = data.title.trim().slice(0, 60);
    if (!title) return fail("Give this version a name.");
    const slug = parseSlug(data.slug);
    if (!slug) return fail("The public slug needs 2–40 letters, numbers, or single hyphens.");
    const content = normalizeContent(data.content);
    const sql = await getSql();
    const plan = await limitFor(sql, context.userId);
    if (!plan) return fail("Claim a public name before you save.");
    if (plan.plan === "free") {
      for (const project of content.projects) project.media = [];
    }
    const packed = JSON.stringify(content);
    if (packed.length > 80_000) return fail("This version is too long to save.");
    try {
      const rows = await sql<{ slug: string }>`
        update versions
        set title = ${title},
            slug = ${slug},
            content = ${packed}::jsonb,
            updated_at = now()
        where id = ${data.id} and user_id = ${context.userId}
        returning slug
      `;
      if (!rows[0]) return fail("That version is not in your studio.");
      await pruneMedia(sql, context.userId);
      return { ok: true, data: { slug: rows[0].slug, storageUsed: await storageOf(sql, context.userId) } };
    } catch (err) {
      if (isUnique(err)) return fail("Another version already uses that slug.");
      throw err;
    }
  });

export const setVisibility = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: string; isPublic: boolean }) => input)
  .handler(async ({ context, data }): Promise<Result<{ isPublic: boolean }>> => {
    const sql = await getSql();
    const rows = await sql<{ id: string }>`
      update versions
      set is_public = ${data.isPublic}, updated_at = now()
      where id = ${data.id} and user_id = ${context.userId}
      returning id
    `;
    if (!rows[0]) return fail("That version is not in your studio.");
    return { ok: true, data: { isPublic: data.isPublic } };
  });

export const deleteVersion = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: string) => id)
  .handler(async ({ context, data }): Promise<Result<{ id: string }>> => {
    const sql = await getSql();
    const rows = await sql<{ id: string }>`
      delete from versions where id = ${data} and user_id = ${context.userId} returning id
    `;
    if (!rows[0]) return fail("That version is not in your studio.");
    await pruneMedia(sql, context.userId);
    return { ok: true, data: { id: rows[0].id } };
  });

export const duplicateVersion = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: string) => id)
  .handler(async ({ context, data }): Promise<Result<{ id: string }>> => {
    const sql = await getSql();
    const plan = await limitFor(sql, context.userId);
    if (!plan) return fail("Claim a public name first.");
    const source = await sql<{ title: string; content: unknown }>`
      select title, content from versions where id = ${data} and user_id = ${context.userId}
    `;
    if (!source[0]) return fail("That version is not in your studio.");
    const id = crypto.randomUUID();
    const title = `Copy of ${source[0].title}`.slice(0, 60);
    const slug = await freeSlug(sql, context.userId, slugify(title));
    const content = JSON.stringify(readContent(source[0].content));
    const rows = await sql<{ id: string }>`
      insert into versions (id, user_id, slug, title, is_public, content)
      select ${id}, ${context.userId}, ${slug}, ${title}, false, ${content}::jsonb
      where (select count(*) from versions where user_id = ${context.userId}) < ${plan.versions}
      returning id
    `;
    if (!rows[0]) {
      return fail(
        plan.plan === "free"
          ? "Free keeps two versions. Become a subscriber to keep four."
          : "A subscriber keeps four versions. Remove one before duplicating.",
      );
    }
    return { ok: true, data: { id: rows[0].id } };
  });

export const setPlan = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((plan: PlanId) => plan)
  .handler(async ({ context, data }): Promise<Result<{ plan: PlanId }>> => {
    const plan = asPlan(data);
    if (data !== "free" && data !== "subscriber") return fail("Unknown plan.");
    const sql = await getSql();
    if (plan === "subscriber") {
      const rows = await sql<{ user_id: string }>`
        update profiles set plan = 'subscriber' where user_id = ${context.userId} returning user_id
      `;
      if (!rows[0]) return fail("Claim a public name before changing plans.");
      return { ok: true, data: { plan } };
    }
    const stored = await storageOf(sql, context.userId);
    if (stored > 0) {
      return fail("Remove photos and shorts, then save, before you move back to Free.");
    }
    const rows = await sql<{ user_id: string }>`
      update profiles
      set plan = 'free'
      where user_id = ${context.userId}
        and (select count(*) from versions where user_id = ${context.userId}) <= ${PLAN_LIMITS.free.versions}
      returning user_id
    `;
    if (rows[0]) return { ok: true, data: { plan: "free" } };
    const exists = await sql`select 1 as ok from profiles where user_id = ${context.userId}`;
    if (!exists[0]) return fail("Claim a public name before changing plans.");
    return fail("Free keeps two versions. Remove extras before you move back.");
  });

export const listPublicIssues = createServerFn({ method: "GET" })
  .validator((handle: string) => handle)
  .handler(async ({ data }): Promise<PublicCard[]> => {
    const handle = data.trim().toLowerCase();
    if (!/^[a-z0-9-]{2,40}$/.test(handle)) return [];
    const sql = await getSql();
    const rows = await sql<{
      slug: string;
      title: string;
      name: string | null;
      role: string | null;
      headline: string | null;
    }>`
      select v.slug, v.title,
             v.content->>'name' as name,
             v.content->>'role' as role,
             v.content->>'headline' as headline
      from versions v
      join profiles p on p.user_id = v.user_id
      where p.handle = ${handle} and v.is_public = true
      order by v.updated_at desc
    `;
    return rows.map((row) => ({
      slug: row.slug,
      title: row.title,
      name: asText(row.name),
      role: asText(row.role),
      headline: asText(row.headline),
    }));
  });

export const getPublicIssue = createServerFn({ method: "GET" })
  .validator((input: { handle: string; slug: string }) => input)
  .handler(async ({ data }): Promise<PublicIssue | null> => {
    const handle = data.handle.trim().toLowerCase();
    const slug = data.slug.trim().toLowerCase();
    if (!/^[a-z0-9-]{2,40}$/.test(handle) || !/^[a-z0-9-]{2,40}$/.test(slug)) return null;
    const sql = await getSql();
    const rows = await sql<{ slug: string; title: string; content: unknown; updated_at: unknown }>`
      select v.slug, v.title, v.content, v.updated_at::text as updated_at
      from versions v
      join profiles p on p.user_id = v.user_id
      where p.handle = ${handle} and v.slug = ${slug} and v.is_public = true
    `;
    const row = rows[0];
    if (!row) return null;
    return {
      slug: row.slug,
      title: row.title,
      updatedAt: asText(row.updated_at),
      content: readContent(row.content),
    };
  });

export const startMedia = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { versionId: string; kind: "photo" | "short"; totalBytes: number }) => input)
  .handler(async ({ context, data }): Promise<Result<{ id: string }>> => {
    const kind = data.kind === "short" ? "short" : data.kind === "photo" ? "photo" : null;
    const totalBytes = Math.floor(Number(data.totalBytes));
    if (!kind || totalBytes < 1) return fail("That file could not be read.");
    const cap = kind === "photo" ? MEDIA.photoMaxBytes : MEDIA.shortMaxBytes;
    if (totalBytes > cap) {
      return fail(kind === "photo" ? "That photo is still too large after reducing it." : "Shorts need to be 8 MB or smaller.");
    }
    if (!isMediaId(data.versionId)) return fail("That version is not in your studio.");
    const sql = await getSql();
    const plan = await limitFor(sql, context.userId);
    if (!plan) return fail("Claim a public name first.");
    if (plan.plan !== "subscriber") return fail("Photos and shorts are on the subscriber plan.");
    const owned = await sql`select 1 as ok from versions where id = ${data.versionId} and user_id = ${context.userId}`;
    if (!owned[0]) return fail("That version is not in your studio.");
    await sql`delete from media where user_id = ${context.userId} and ready = false`;
    const id = crypto.randomUUID();
    const rows = await sql<{ id: string }>`
      insert into media (id, user_id, kind, mime, bytes, data, ready)
      select ${id}, ${context.userId}, ${kind}, 'application/octet-stream', ${totalBytes}, ''::bytea, false
      where (select coalesce(sum(bytes), 0)::int from media where user_id = ${context.userId}) + ${totalBytes} <= ${MEDIA.storageBytes}
      returning id
    `;
    if (!rows[0]) return fail("That file does not fit in the 40 MB subscriber storage.");
    return { ok: true, data: { id } };
  });

export const appendMedia = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: string; dataBase64: string }) => input)
  .handler(async ({ context, data }): Promise<Result<{ received: number }>> => {
    if (!isMediaId(data.id)) return fail("That upload was not found.");
    const chunk = decodeChunk(data.dataBase64);
    if (!chunk) return fail("That piece of the file was too large. Try again.");
    const sql = await getSql();
    const rows = await sql.query<{ size: unknown }>(
      `update media
       set data = data || $1::bytea
       where id = $2 and user_id = $3 and ready = false
         and octet_length(data) + octet_length($1::bytea) <= bytes
       returning octet_length(data) as size`,
      [chunk, data.id, context.userId],
    );
    if (!rows[0]) return fail("Upload was interrupted. Try that file again.");
    return { ok: true, data: { received: asNumber(rows[0].size) } };
  });

export const finishMedia = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: string) => id)
  .handler(async ({ context, data }): Promise<Result<{ id: string; kind: "photo" | "short"; mime: string; storageUsed: number }>> => {
    if (!isMediaId(data)) return fail("That upload was not found.");
    const sql = await getSql();
    const rows = await sql<{ kind: string; bytes: unknown; data: unknown }>`
      select kind, bytes, data from media
      where id = ${data} and user_id = ${context.userId} and ready = false
    `;
    const row = rows[0];
    if (!row) return fail("That upload was not found.");
    const bytes = toBytes(row.data);
    const expected = asNumber(row.bytes);
    const kind = row.kind === "short" ? "short" : "photo";
    const sniffed = bytes ? sniff(bytes) : null;
    const cap = kind === "photo" ? MEDIA.photoMaxBytes : MEDIA.shortMaxBytes;
    if (!bytes || bytes.byteLength !== expected || !sniffed || sniffed.kind !== kind || bytes.byteLength > cap) {
      await sql`delete from media where id = ${data} and user_id = ${context.userId} and ready = false`;
      return fail(kind === "photo" ? "That photo could not be stored." : "Use an MP4 or WebM short.");
    }
    await sql`
      update media set mime = ${sniffed.mime}, ready = true
      where id = ${data} and user_id = ${context.userId}
    `;
    return {
      ok: true,
      data: { id: data, kind, mime: sniffed.mime, storageUsed: await storageOf(sql, context.userId) },
    };
  });

export const readOwnMedia = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((id: string) => id)
  .handler(
    async ({
      context,
      data,
    }): Promise<Result<{ id: string; kind: "photo" | "short"; mime: string; bytes: number; base64?: string }>> => {
      if (!isMediaId(data)) return fail("That file was not found.");
      const sql = await getSql();
      const rows = await sql<{ kind: string; mime: string; bytes: unknown; data: unknown }>`
        select kind, mime, bytes, case when kind = 'photo' then data else ''::bytea end as data
        from media
        where id = ${data} and user_id = ${context.userId} and ready = true
      `;
      const row = rows[0];
      if (!row) return fail("That file was not found.");
      const kind = row.kind === "short" ? "short" : "photo";
      const bytes = asNumber(row.bytes);
      if (kind === "short") return { ok: true, data: { id: data, kind, mime: row.mime, bytes } };
      const raw = toBytes(row.data);
      if (!raw || raw.byteLength === 0) return fail("That photo could not be read.");
      return {
        ok: true,
        data: { id: data, kind, mime: row.mime, bytes, base64: Buffer.from(raw).toString("base64") },
      };
    },
  );

