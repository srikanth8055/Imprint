import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { signOut } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export function ProductBar({ notice }: { notice?: string }) {
  return (
    <header className="sticky top-0 z-30 border-b border-ink/15 bg-paper">
      <a
        href="#content"
        className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-50 focus:bg-ink focus:px-3 focus:py-2 focus:text-paper"
      >
        Skip to content
      </a>
      <div className="shell flex flex-col gap-3 py-3 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center justify-between gap-4">
          <Link to="/" className="font-display text-xl tracking-tight">
            Imprint
          </Link>
          <nav className="flex items-center gap-4 text-sm" aria-label="Studio">
            <Link to="/plans" className="underline-offset-4 hover:underline">
              Plans
            </Link>
            <Link to="/studio" className="underline-offset-4 hover:underline">
              Studio
            </Link>
          </nav>
        </div>
        <AuthSlot />
      </div>
      {notice ? <p className="shell pb-3 text-sm text-pretty text-muted">{notice}</p> : null}
    </header>
  );
}

function AuthSlot() {
  const { user, isPending } = useCurrentUserState();
  const [signingOut, setSigningOut] = useState(false);

  if (isPending) return <p className="text-sm text-muted">Checking account…</p>;

  if (!user) {
    return (
      <Link to="/login" className="btn-ink w-fit min-h-11 px-4 text-sm">
        Sign in
      </Link>
    );
  }

  const label = user.displayName ?? user.primaryEmail ?? "Account";
  return (
    <div className="flex flex-wrap items-center gap-3">
      <p className="text-sm">
        Signed in as <span className="font-medium">{label}</span>
      </p>
      <button
        type="button"
        className="btn-line min-h-11 px-4 text-sm"
        disabled={signingOut}
        onClick={() => {
          setSigningOut(true);
          void signOut().catch(() => setSigningOut(false));
        }}
      >
        {signingOut ? "Signing out…" : "Sign out"}
      </button>
    </div>
  );
}
