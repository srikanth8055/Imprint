import { useState, type FormEvent } from "react";
import { Link } from "@tanstack/react-router";
import {
  categoriesOf,
  isEmail,
  paragraphs,
  type PortfolioContent,
  type Project,
} from "@/lib/portfolio-model";

type IssueNav =
  | { kind: "sample" }
  | { kind: "member"; handle: string; slug: string };

export function IssueView({
  content,
  issueLabel,
  nav,
  credit,
}: {
  content: PortfolioContent;
  issueLabel: string;
  nav: IssueNav;
  credit: "specimen" | "member";
}) {
  const categories = categoriesOf(content.projects);
  const [filter, setFilter] = useState("All");
  const [openId, setOpenId] = useState<number | null>(null);
  const visible =
    filter === "All" ? content.projects : content.projects.filter((project) => project.category === filter);
  const name = content.name || "Untitled";
  const headline = content.headline || "An issue without a headline yet.";

  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b border-ink/15">
        <div className="shell flex min-h-16 flex-wrap items-center justify-between gap-x-4 gap-y-2 py-3">
          <HomeLink nav={nav} className="font-display text-2xl tracking-tight">
            {name}
          </HomeLink>
          <nav className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm" aria-label="Issue">
            <a href="#work" className="underline-offset-4 hover:underline">
              Work
            </a>
            <a href="#about" className="underline-offset-4 hover:underline">
              About
            </a>
            <a href="#skills" className="underline-offset-4 hover:underline">
              Skills
            </a>
            <a href="#contact" className="underline-offset-4 hover:underline">
              Contact
            </a>
            <BioLink nav={nav} className="underline-offset-4 hover:underline">
              Bio
            </BioLink>
          </nav>
        </div>
      </header>

      <main id="content" className="flex-1">
        <section className="shell grid items-end gap-10 py-14 md:grid-cols-12 md:py-20">
          <div className="md:col-span-8">
            <p className="text-xs font-medium tracking-eyebrow text-pine uppercase">
              {issueLabel}
              {content.location ? ` · ${content.location}` : ""}
            </p>
            <h1 className="mt-4 font-display text-hero">{headline}</h1>
            {content.deck ? <p className="mt-6 max-w-xl text-lg text-muted">{content.deck}</p> : null}
            <div className="mt-8 flex flex-wrap gap-3">
              <a href="#work" className="btn-ink">
                View the work
              </a>
              <BioLink nav={nav} className="btn-line">
                Read the bio
              </BioLink>
            </div>
          </div>
          <aside className="border border-ink/15 p-6 md:col-span-4">
            <p className="text-xs font-medium tracking-eyebrow text-muted uppercase">Masthead</p>
            <p className="mt-3 font-display text-3xl">{name}</p>
            {content.role ? <p className="mt-2 text-muted">{content.role}</p> : null}
            <p className="mt-6 text-sm">
              {content.projects.length.toString().padStart(2, "0")} pieces in this version
            </p>
          </aside>
        </section>

        <section id="work" className="border-t border-ink/15">
          <div className="shell py-14 md:py-20">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <h2 className="font-display text-section">Selected work</h2>
              <p className="text-sm text-muted tabular-nums" aria-live="polite">
                {visible.length.toString().padStart(2, "0")} shown
              </p>
            </div>
            <div className="mt-6 flex flex-wrap gap-2" role="group" aria-label="Filter projects">
              {["All", ...categories].map((category) => (
                <button
                  key={category}
                  type="button"
                  className="chip"
                  aria-pressed={filter === category}
                  onClick={() => {
                    setFilter(category);
                    setOpenId(null);
                  }}
                >
                  {category}
                </button>
              ))}
            </div>
            {visible.length === 0 ? (
              <p className="mt-10 max-w-md text-muted">No pieces in this issue yet.</p>
            ) : (
              <ul className="mt-8 grid gap-8 md:grid-cols-2">
                {visible.map((project, index) => {
                  const feature = filter === "All" && index === 0;
                  const absolute = content.projects.indexOf(project);
                  const open = openId === absolute;
                  return (
                    <li
                      key={`${project.title}-${absolute}`}
                      className={feature ? "project-card is-feature md:col-span-2" : "project-card"}
                      data-open={open ? "true" : "false"}
                    >
                      <ProjectCover project={project} index={absolute} open={open} onToggle={() => setOpenId(open ? null : absolute)} />
                      <div className="mt-4 flex items-baseline justify-between gap-4">
                        <h3 className="font-display text-2xl">{project.title}</h3>
                        {project.year ? <p className="text-sm text-muted tabular-nums">{project.year}</p> : null}
                      </div>
                      <p className="mt-1 text-sm text-muted">
                        {project.category}
                        {project.role ? ` · ${project.role}` : ""}
                      </p>
                      <ProjectMediaStrip project={project} />
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </section>

        <section id="about" className="border-t border-ink/15 bg-wash">
          <div className="shell grid gap-8 py-14 md:grid-cols-12 md:py-20">
            <h2 className="font-display text-section md:col-span-4">About</h2>
            <div className="max-w-prose md:col-span-8">
              {paragraphs(content.about).length === 0 ? (
                <p className="text-muted">This version has no about text yet.</p>
              ) : (
                paragraphs(content.about).map((paragraph) => (
                  <p key={paragraph.slice(0, 24)} className="mt-4 first:mt-0">
                    {paragraph}
                  </p>
                ))
              )}
              <BioLink nav={nav} className="btn-line mt-8">
                Full bio
              </BioLink>
            </div>
          </div>
        </section>

        <section id="skills" className="border-t border-ink/15">
          <div className="shell py-14 md:py-20">
            <h2 className="font-display text-section">Skills</h2>
            {content.skills.length === 0 ? (
              <p className="mt-6 text-muted">No skills listed on this version.</p>
            ) : (
              <div className="mt-8 grid gap-10 md:grid-cols-2">
                {content.skills.map((group) => (
                  <div key={group.group}>
                    <h3 className="text-xs font-medium tracking-eyebrow text-pine uppercase">{group.group}</h3>
                    <dl className="mt-4 divide-y divide-ink/15 border-y border-ink/15">
                      {group.items.map((item) => (
                        <div key={item.name} className="grid gap-1 py-3 sm:grid-cols-2 sm:gap-4">
                          <dt>{item.name}</dt>
                          <dd className="text-muted">{item.detail}</dd>
                        </div>
                      ))}
                    </dl>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>

        <ContactBlock content={content} />
      </main>

      <IssueFooter content={content} nav={nav} credit={credit} issueLabel={issueLabel} />
    </div>
  );
}

export function BioView({
  content,
  issueLabel,
  nav,
  credit,
}: {
  content: PortfolioContent;
  issueLabel: string;
  nav: IssueNav;
  credit: "specimen" | "member";
}) {
  const name = content.name || "Untitled";
  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b border-ink/15">
        <div className="shell flex min-h-16 flex-wrap items-center justify-between gap-3 py-3">
          <HomeLink nav={nav} className="font-display text-2xl">
            {name}
          </HomeLink>
          <HomeLink nav={nav} className="text-sm underline-offset-4 hover:underline">
            Back to the issue
          </HomeLink>
        </div>
      </header>
      <main id="content" className="shell flex-1 py-14 md:py-20">
        <p className="text-xs font-medium tracking-eyebrow text-pine uppercase">Bio · {issueLabel}</p>
        <h1 className="mt-4 max-w-3xl font-display text-section">{content.headline || name}</h1>
        <p className="mt-4 text-muted">
          {name}
          {content.role ? ` · ${content.role}` : ""}
          {content.location ? ` · ${content.location}` : ""}
        </p>
        <div className="mt-10 grid gap-12 lg:grid-cols-12">
          <article className="max-w-prose lg:col-span-7">
            {paragraphs(content.bio).length === 0 ? (
              <p className="text-muted">This version has no bio yet.</p>
            ) : (
              paragraphs(content.bio).map((paragraph) => (
                <p key={paragraph.slice(0, 32)} className="mt-5 first:mt-0 text-lg">
                  {paragraph}
                </p>
              ))
            )}
          </article>
          <aside className="lg:col-span-5">
            {content.now.length > 0 ? (
              <div>
                <h2 className="text-xs font-medium tracking-eyebrow text-pine uppercase">Now</h2>
                <ul className="mt-4 space-y-3">
                  {content.now.map((item) => (
                    <li key={item} className="border-t border-ink/15 pt-3">
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
            {content.timeline.length > 0 ? (
              <div className="mt-10">
                <h2 className="text-xs font-medium tracking-eyebrow text-pine uppercase">Then</h2>
                <ol className="mt-4">
                  {content.timeline.map((entry) => (
                    <li key={`${entry.year}-${entry.text}`} className="grid grid-cols-[4.5rem_1fr] gap-3 border-t border-ink/15 py-3">
                      <span className="text-sm text-muted tabular-nums">{entry.year}</span>
                      <span>{entry.text}</span>
                    </li>
                  ))}
                </ol>
              </div>
            ) : null}
          </aside>
        </div>
      </main>
      <IssueFooter content={content} nav={nav} credit={credit} issueLabel={issueLabel} />
    </div>
  );
}

function ContactBlock({ content }: { content: PortfolioContent }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [errors, setErrors] = useState<{ name?: string; email?: string; message?: string }>({});
  const [sent, setSent] = useState(false);
  const [copied, setCopied] = useState(false);
  const listed = isEmail(content.email) ? content.email.trim() : "";

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    const next: typeof errors = {};
    if (!name.trim()) next.name = "Add your name.";
    if (!isEmail(email)) next.email = "That email does not look complete.";
    if (message.trim().length < 12) next.message = "A sentence or two is enough.";
    setErrors(next);
    if (Object.keys(next).length > 0) return;
    setSent(true);
    setCopied(false);
  }

  async function copyNote() {
    const body = `From ${name.trim()} <${email.trim()}>\n\n${message.trim()}`;
    try {
      await navigator.clipboard.writeText(body);
      setCopied(true);
    } catch {
      setCopied(false);
    }
  }

  return (
    <section id="contact" className="border-t border-ink/15 bg-ink text-paper">
      <div className="shell grid gap-10 py-14 md:grid-cols-12 md:py-20">
        <div className="md:col-span-5">
          <h2 className="font-display text-section">Write</h2>
          <p className="mt-4 max-w-sm text-paper/80">
            {content.contactNote || "A short note is enough. Say what you are making."}
          </p>
          {listed ? (
            <p className="mt-6 text-sm">
              Listed address:{" "}
              <a className="underline underline-offset-4" href={`mailto:${listed}`}>
                {listed}
              </a>
            </p>
          ) : (
            <p className="mt-6 text-sm text-paper/70">This version does not list an email address.</p>
          )}
        </div>
        <div className="md:col-span-7">
          {sent ? (
            <div className="border border-paper/25 p-6">
              <p className="font-display text-3xl">Noted, {name.trim()}.</p>
              <p className="mt-3 text-paper/80">
                Nothing was emailed. {listed ? `Copy the note and send it to ${listed}.` : "Copy it if you want to keep it."}
              </p>
              <div className="mt-6 flex flex-wrap gap-3">
                <button type="button" className="btn-line on-ink" onClick={() => void copyNote()}>
                  {copied ? "Copied" : "Copy note"}
                </button>
                <button
                  type="button"
                  className="btn-ghost text-paper"
                  onClick={() => {
                    setSent(false);
                    setMessage("");
                  }}
                >
                  Write another
                </button>
              </div>
            </div>
          ) : (
            <form className="grid gap-5" onSubmit={onSubmit} noValidate>
              <label className="grid gap-1 text-sm">
                Name
                <input className="field on-ink" value={name} onChange={(event) => setName(event.target.value)} autoComplete="name" />
                {errors.name ? <span className="text-wash">{errors.name}</span> : null}
              </label>
              <label className="grid gap-1 text-sm">
                Email
                <input
                  className="field on-ink"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  autoComplete="email"
                  inputMode="email"
                />
                {errors.email ? <span className="text-wash">{errors.email}</span> : null}
              </label>
              <label className="grid gap-1 text-sm">
                Note
                <textarea className="field on-ink" value={message} onChange={(event) => setMessage(event.target.value)} />
                {errors.message ? <span className="text-wash">{errors.message}</span> : null}
              </label>
              <button type="submit" className="btn-line on-ink w-fit">
                Prepare note
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}

function IssueFooter({
  content,
  nav,
  credit,
  issueLabel,
}: {
  content: PortfolioContent;
  nav: IssueNav;
  credit: "specimen" | "member";
  issueLabel: string;
}) {
  const name = content.name || "Untitled";
  return (
    <footer className="border-t border-ink/15">
      <div className="shell grid gap-10 py-12 md:grid-cols-12">
        <div className="md:col-span-5">
          <p className="font-display text-4xl">{name}</p>
          <p className="mt-3 max-w-sm text-sm text-muted">
            {issueLabel}. {content.role || "A public version on Imprint."}
          </p>
        </div>
        <div className="md:col-span-3">
          <p className="text-xs font-medium tracking-eyebrow text-muted uppercase">In this issue</p>
          <ul className="mt-3 space-y-2 text-sm">
            <li>
              <SectionLink nav={nav} hash="work">Work</SectionLink>
            </li>
            <li>
              <SectionLink nav={nav} hash="about">About</SectionLink>
            </li>
            <li>
              <SectionLink nav={nav} hash="skills">Skills</SectionLink>
            </li>
            <li>
              <SectionLink nav={nav} hash="contact">Contact</SectionLink>
            </li>
            <li>
              <BioLink nav={nav} className="underline-offset-4 hover:underline">
                Bio
              </BioLink>
            </li>
          </ul>
        </div>
        <div className="md:col-span-4">
          <p className="text-xs font-medium tracking-eyebrow text-muted uppercase">Elsewhere</p>
          <ul className="mt-3 space-y-2 text-sm">
            {isEmail(content.email) ? (
              <li>
                <a className="break-all underline-offset-4 hover:underline" href={`mailto:${content.email.trim()}`}>
                  {content.email.trim()}
                </a>
              </li>
            ) : null}
            {content.links.map((link) => (
              <li key={link.href}>
                <a className="break-all underline-offset-4 hover:underline" href={link.href} rel="noreferrer" target="_blank">
                  {link.label}
                </a>
              </li>
            ))}
            {content.links.length === 0 && !isEmail(content.email) ? <li className="text-muted">No links listed.</li> : null}
          </ul>
        </div>
      </div>
      <div className="shell flex flex-wrap items-center justify-between gap-3 border-t border-ink/15 py-4 text-sm text-muted">
        <p>© {new Date().getFullYear()} {name}</p>
        {credit === "specimen" ? (
          <p>
            Specimen, not a member.{" "}
            <Link to="/plans" className="text-ink underline-offset-4 hover:underline">
              See plans
            </Link>
          </p>
        ) : (
          <p>
            Published with{" "}
            <Link to="/" className="text-ink underline-offset-4 hover:underline">
              Imprint
            </Link>
          </p>
        )}
      </div>
    </footer>
  );
}

function mediaSrc(id: string): string {
  return `/api/media/${id}`;
}

function ProjectCover({
  project,
  index,
  open,
  onToggle,
}: {
  project: Project;
  index: number;
  open: boolean;
  onToggle: () => void;
}) {
  const photo = (project.media ?? []).find((item) => item.kind === "photo");
  const art = photo ? null : (
    <CoverArt
      title={project.title}
      index={String(index + 1).padStart(2, "0")}
      year={project.year}
      category={project.category}
      layout={index % 3}
    />
  );
  return (
    <div className="cover">
      {photo ? <img className="cover-photo" src={mediaSrc(photo.id)} alt="" /> : null}
      {project.summary ? (
        <button type="button" className="cover-hit" aria-expanded={open} onClick={onToggle}>
          {art}
          <span className="blurb">
            <span className="text-xs font-medium tracking-eyebrow uppercase">{open ? "Close" : "Note"}</span>
            <span className="mt-2 block text-base">{project.summary}</span>
          </span>
        </button>
      ) : (
        <div className="cover-hit">{art}</div>
      )}
    </div>
  );
}

function ProjectMediaStrip({ project }: { project: Project }) {
  const photos = (project.media ?? []).filter((item) => item.kind === "photo").slice(1);
  const short = (project.media ?? []).find((item) => item.kind === "short");
  if (photos.length === 0 && !short) return null;
  return (
    <div className="mt-4 grid gap-3">
      {photos.map((item) => (
        <img key={item.id} src={mediaSrc(item.id)} alt={project.title} className="w-full border border-ink/10" />
      ))}
      {short ? (
        <video className="w-full bg-ink" controls playsInline preload="metadata" src={mediaSrc(short.id)} />
      ) : null}
    </div>
  );
}

function CoverArt({
  title,
  index,
  year,
  category,
  layout,
}: {
  title: string;
  index: string;
  year: string;
  category: string;
  layout: number;
}) {
  return (
    <div className="flex h-full flex-col justify-between p-5" aria-hidden="true">
      <div className="flex items-center justify-between text-xs font-medium tracking-eyebrow text-muted uppercase">
        <span>{category}</span>
        <span>{year || index}</span>
      </div>
      {layout === 2 ? (
        <p className="font-display text-7xl leading-none md:text-8xl">{index}</p>
      ) : layout === 1 ? (
        <p className="font-display text-4xl leading-none md:text-5xl">
          {title.split(" ").map((word, index) => (
            <span key={`${word}-${index}`} className="block">
              {word}
            </span>
          ))}
        </p>
      ) : (
        <p className="font-display text-5xl leading-display italic md:text-6xl">{title}</p>
      )}
      <p className="text-sm text-muted">{layout === 2 ? title : index}</p>
    </div>
  );
}

function SectionLink({ nav, hash, children }: { nav: IssueNav; hash: string; children: React.ReactNode }) {
  const className = "underline-offset-4 hover:underline";
  if (nav.kind === "sample") {
    return (
      <Link to="/" hash={hash} className={className}>
        {children}
      </Link>
    );
  }
  return (
    <Link to="/p/$handle/$slug" params={{ handle: nav.handle, slug: nav.slug }} hash={hash} className={className}>
      {children}
    </Link>
  );
}

function HomeLink({ nav, className, children }: { nav: IssueNav; className?: string; children: React.ReactNode }) {
  if (nav.kind === "sample") {
    return (
      <Link to="/" className={className}>
        {children}
      </Link>
    );
  }
  return (
    <Link to="/p/$handle/$slug" params={{ handle: nav.handle, slug: nav.slug }} className={className}>
      {children}
    </Link>
  );
}

function BioLink({ nav, className, children }: { nav: IssueNav; className?: string; children: React.ReactNode }) {
  if (nav.kind === "sample") {
    return (
      <Link to="/sample/bio" className={className}>
        {children}
      </Link>
    );
  }
  return (
    <Link to="/p/$handle/$slug/bio" params={{ handle: nav.handle, slug: nav.slug }} className={className}>
      {children}
    </Link>
  );
}
