import { useEffect, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { appendMedia, finishMedia, readOwnMedia, saveVersion, setVisibility, deleteVersion, startMedia } from "@/lib/portfolio.functions";
import { MEDIA, formatBytes, type PlanId, type PortfolioContent, type Project, type SkillGroup, type TimelineEntry, type VersionDetail } from "@/lib/portfolio-model";

export function VersionEditor({
  version,
  handle,
  plan,
  storageUsed,
  storageLimit,
}: {
  version: VersionDetail;
  handle: string;
  plan: PlanId;
  storageUsed: number;
  storageLimit: number;
}) {
  const navigate = useNavigate();
  const [title, setTitle] = useState(version.title);
  const [slug, setSlug] = useState(version.slug);
  const [content, setContent] = useState<PortfolioContent>(version.content);
  const [isPublic, setIsPublic] = useState(version.isPublic);
  const [stored, setStored] = useState(storageUsed);
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  function patch(partial: Partial<PortfolioContent>) {
    setContent((current) => ({ ...current, ...partial }));
  }

  async function persist(nextPublic = isPublic) {
    setBusy(true);
    setError("");
    setStatus("");
    try {
      const saved = await saveVersion({ data: { id: version.id, title, slug, content } });
      if (!saved.ok) {
        setError(saved.error);
        return;
      }
      setSlug(saved.data.slug);
      setStored(saved.data.storageUsed);
      if (nextPublic !== isPublic) {
        const vis = await setVisibility({ data: { id: version.id, isPublic: nextPublic } });
        if (!vis.ok) {
          setError(vis.error);
          return;
        }
        setIsPublic(vis.data.isPublic);
      }
      setStatus(nextPublic ? "Saved and public." : "Saved as a draft.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save.");
    } finally {
      setBusy(false);
    }
  }

  async function remove() {
    setBusy(true);
    setError("");
    try {
      const result = await deleteVersion({ data: version.id });
      if (!result.ok) {
        setError(result.error);
        setBusy(false);
        return;
      }
      await navigate({ to: "/studio" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not delete.");
      setBusy(false);
    }
  }

  const publicPath = `/p/${handle}/${slug || version.slug}`;

  return (
    <form
      className="shell py-10"
      onSubmit={(event) => {
        event.preventDefault();
        void persist();
      }}
    >
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <Link to="/studio" className="text-sm underline-offset-4 hover:underline">
            All versions
          </Link>
          <h1 className="mt-2 font-display text-section">Edit version</h1>
          <p className="mt-2 text-sm text-muted">{isPublic ? "Public" : "Draft"} · {publicPath}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button type="submit" className="btn-ink" disabled={busy}>
            {busy ? "Saving…" : "Save"}
          </button>
          <button
            type="button"
            className="btn-line"
            disabled={busy}
            onClick={() => void persist(!isPublic)}
          >
            {isPublic ? "Unpublish" : "Publish"}
          </button>
        </div>
      </div>
      {error ? <p className="mt-4 text-sm text-danger">{error}</p> : null}
      {status ? <p className="mt-4 text-sm text-pine">{status}</p> : null}

      <fieldset className="mt-10 grid gap-4 border-0 p-0 md:grid-cols-2">
        <legend className="font-display text-2xl">This version</legend>
        <label className="mt-4 grid gap-1 text-sm">
          Version name
          <input className="field" value={title} maxLength={60} onChange={(event) => setTitle(event.target.value)} />
        </label>
        <label className="mt-4 grid gap-1 text-sm">
          Public slug
          <input className="field" value={slug} maxLength={40} onChange={(event) => setSlug(event.target.value.toLowerCase())} />
        </label>
      </fieldset>

      <fieldset className="mt-12 grid gap-4 border-0 p-0">
        <legend className="font-display text-2xl">Masthead</legend>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <Field label="Name" value={content.name} onChange={(name) => patch({ name })} maxLength={80} />
          <Field label="Role" value={content.role} onChange={(role) => patch({ role })} maxLength={80} />
          <Field label="Location" value={content.location} onChange={(location) => patch({ location })} maxLength={80} />
          <Field label="Email" value={content.email} onChange={(email) => patch({ email })} maxLength={120} />
        </div>
        <Field label="Headline" value={content.headline} onChange={(headline) => patch({ headline })} maxLength={160} />
        <Area label="Deck" value={content.deck} onChange={(deck) => patch({ deck })} maxLength={320} />
      </fieldset>

      <fieldset className="mt-12 grid gap-4 border-0 p-0">
        <legend className="font-display text-2xl">About and bio</legend>
        <Area label="About, on the home page" value={content.about} onChange={(about) => patch({ about })} maxLength={1200} />
        <Area label="Bio page" value={content.bio} onChange={(bio) => patch({ bio })} maxLength={5000} />
        <Lines
          label="Now — one line each"
          rows={content.now}
          onChange={(now) => patch({ now })}
          placeholder="What you are doing"
        />
        <Timeline rows={content.timeline} onChange={(timeline) => patch({ timeline })} />
      </fieldset>

      <Projects
        rows={content.projects}
        onChange={(projects) => patch({ projects })}
        versionId={version.id}
        plan={plan}
        storageUsed={stored}
        storageLimit={storageLimit}
        onStorage={setStored}
      />
      <Skills rows={content.skills} onChange={(skills) => patch({ skills })} />

      <fieldset className="mt-12 grid gap-4 border-0 p-0">
        <legend className="font-display text-2xl">Contact</legend>
        <Area
          label="Note above the form"
          value={content.contactNote}
          onChange={(contactNote) => patch({ contactNote })}
          maxLength={400}
        />
        <p className="text-sm text-muted">
          The form does not send mail. Visitors can copy a note. If you list an email, they are pointed at it.
        </p>
        <Links rows={content.links} onChange={(links) => patch({ links })} />
      </fieldset>

      <div className="mt-12 flex flex-wrap items-center gap-3 border-t border-ink/15 pt-6">
        {isPublic ? (
          <a className="btn-line" href={publicPath}>
            Open public page
          </a>
        ) : (
          <p className="text-sm text-muted">Publish to open the public page.</p>
        )}
        {confirmDelete ? (
          <>
            <span className="text-sm">Delete this version?</span>
            <button type="button" className="btn-ink" disabled={busy} onClick={() => void remove()}>
              Delete
            </button>
            <button type="button" className="btn-ghost" onClick={() => setConfirmDelete(false)}>
              Cancel
            </button>
          </>
        ) : (
          <button type="button" className="btn-ghost" onClick={() => setConfirmDelete(true)}>
            Delete version
          </button>
        )}
      </div>
    </form>
  );
}

function Field({
  label,
  value,
  onChange,
  maxLength,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  maxLength: number;
}) {
  return (
    <label className="grid gap-1 text-sm">
      {label}
      <input className="field" value={value} maxLength={maxLength} onChange={(event) => onChange(event.target.value)} />
    </label>
  );
}

function Area({
  label,
  value,
  onChange,
  maxLength,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  maxLength: number;
}) {
  return (
    <label className="grid gap-1 text-sm">
      {label}
      <textarea className="field" value={value} maxLength={maxLength} onChange={(event) => onChange(event.target.value)} />
    </label>
  );
}

function Lines({
  label,
  rows,
  onChange,
  placeholder,
}: {
  label: string;
  rows: string[];
  onChange: (rows: string[]) => void;
  placeholder: string;
}) {
  return (
    <div>
      <p className="text-sm">{label}</p>
      <div className="mt-2 grid gap-2">
        {rows.map((row, index) => (
          <div key={index} className="flex gap-2">
            <input
              className="field"
              value={row}
              placeholder={placeholder}
              maxLength={120}
              onChange={(event) => onChange(rows.map((item, i) => (i === index ? event.target.value : item)))}
            />
            <button type="button" className="btn-ghost" onClick={() => onChange(rows.filter((_, i) => i !== index))}>
              Remove
            </button>
          </div>
        ))}
      </div>
      {rows.length < 6 ? (
        <button type="button" className="btn-line mt-3" onClick={() => onChange([...rows, ""])}>
          Add line
        </button>
      ) : null}
    </div>
  );
}

function Timeline({ rows, onChange }: { rows: TimelineEntry[]; onChange: (rows: TimelineEntry[]) => void }) {
  return (
    <div>
      <p className="text-sm">Timeline</p>
      <div className="mt-2 grid gap-3">
        {rows.map((row, index) => (
          <div key={index} className="grid gap-2 sm:grid-cols-[6rem_1fr_auto]">
            <input
              className="field"
              value={row.year}
              placeholder="Year"
              maxLength={16}
              onChange={(event) =>
                onChange(rows.map((item, i) => (i === index ? { ...item, year: event.target.value } : item)))
              }
            />
            <input
              className="field"
              value={row.text}
              placeholder="What happened"
              maxLength={160}
              onChange={(event) =>
                onChange(rows.map((item, i) => (i === index ? { ...item, text: event.target.value } : item)))
              }
            />
            <button type="button" className="btn-ghost" onClick={() => onChange(rows.filter((_, i) => i !== index))}>
              Remove
            </button>
          </div>
        ))}
      </div>
      {rows.length < 8 ? (
        <button type="button" className="btn-line mt-3" onClick={() => onChange([...rows, { year: "", text: "" }])}>
          Add year
        </button>
      ) : null}
    </div>
  );
}

function Projects({
  rows,
  onChange,
  versionId,
  plan,
  storageUsed,
  storageLimit,
  onStorage,
}: {
  rows: Project[];
  onChange: (rows: Project[]) => void;
  versionId: string;
  plan: PlanId;
  storageUsed: number;
  storageLimit: number;
  onStorage: (bytes: number) => void;
}) {
  const [previews, setPreviews] = useState<Record<string, string>>({});
  const [mediaError, setMediaError] = useState("");
  const [uploading, setUploading] = useState("");

  async function upload(index: number, kind: "photo" | "short", file: File | null) {
    if (!file) return;
    const project = rows[index];
    if (!project?.title.trim()) {
      setMediaError("Add a title before attaching a file. Untitled projects are not saved.");
      return;
    }
    const media = project.media ?? [];
    const photos = media.filter((item) => item.kind === "photo").length;
    const shorts = media.filter((item) => item.kind === "short").length;
    if (kind === "photo" && photos >= MEDIA.photosPerProject) return;
    if (kind === "short" && shorts >= MEDIA.shortsPerProject) return;
    setMediaError("");
    setUploading(`${kind}-${index}`);
    try {
      const prepared = kind === "photo" ? await preparePhoto(file) : await prepareShort(file);
      const storedFile = await sendMedia(versionId, kind, prepared.bytes);
      onChange(
        rows.map((row, i) =>
          i === index ? { ...row, media: [...(row.media ?? []), { id: storedFile.id, kind }] } : row,
        ),
      );
      setPreviews((current) => ({
        ...current,
        [storedFile.id]: URL.createObjectURL(new Blob([prepared.bytes.slice()])),
      }));
      onStorage(storedFile.storageUsed);
    } catch (err) {
      setMediaError(err instanceof Error ? err.message : "Could not add that file.");
    } finally {
      setUploading("");
    }
  }

  function removeMedia(index: number, id: string) {
    onChange(rows.map((row, i) => (i === index ? { ...row, media: (row.media ?? []).filter((item) => item.id !== id) } : row)));
  }

  return (
    <fieldset className="mt-12 border-0 p-0">
      <legend className="font-display text-2xl">Work</legend>
      <p className="mt-2 max-w-xl text-sm text-muted">
        The short summary is what appears when someone hovers a project, or taps Note.
      </p>
      {plan === "subscriber" ? (
        <p className="mt-2 max-w-xl text-sm text-muted">
          {formatBytes(storageUsed)} of {formatBytes(storageLimit)} used. Photos are reduced before they are stored. Shorts must
          already be MP4 or WebM, 30 seconds or less, and under 8 MB — they are not re-encoded. Save to keep new files, and to
          free space after you remove one.
        </p>
      ) : (
        <p className="mt-2 max-w-xl text-sm text-muted">
          Photos and shorts are on Subscriber, with 40 MB of hosted media.{" "}
          <Link to="/plans" className="text-ink underline-offset-4 hover:underline">
            See plans
          </Link>
          .
        </p>
      )}
      {mediaError ? <p className="mt-3 text-sm text-danger">{mediaError}</p> : null}
      <div className="mt-4 grid gap-6">
        {rows.map((project, index) => {
          const media = project.media ?? [];
          const photos = media.filter((item) => item.kind === "photo");
          const short = media.find((item) => item.kind === "short");
          return (
            <div key={index} className="grid gap-3 border border-ink/15 p-4">
              <div className="grid gap-3 md:grid-cols-3">
                <Field label="Title" value={project.title} maxLength={80} onChange={(title) => updateProject(rows, index, { title }, onChange)} />
                <Field label="Year" value={project.year} maxLength={12} onChange={(year) => updateProject(rows, index, { year }, onChange)} />
                <Field
                  label="Category"
                  value={project.category}
                  maxLength={32}
                  onChange={(category) => updateProject(rows, index, { category }, onChange)}
                />
              </div>
              <Field label="Role" value={project.role} maxLength={80} onChange={(role) => updateProject(rows, index, { role }, onChange)} />
              <Area
                label="Hover note"
                value={project.summary}
                maxLength={280}
                onChange={(summary) => updateProject(rows, index, { summary }, onChange)}
              />
              {plan === "subscriber" ? (
                <div className="grid gap-3">
                  {photos.map((item) => (
                    <div key={item.id} className="grid gap-2">
                      <PhotoPreview id={item.id} src={previews[item.id]} />
                      <button type="button" className="btn-ghost w-fit" onClick={() => removeMedia(index, item.id)}>
                        Remove photo
                      </button>
                    </div>
                  ))}
                  {short ? (
                    <div className="grid gap-2">
                      {previews[short.id] ? (
                        <video className="w-full bg-ink" controls playsInline src={previews[short.id]} />
                      ) : (
                        <p className="text-sm text-muted">Short stored. It plays on the public page after you save and publish.</p>
                      )}
                      <button type="button" className="btn-ghost w-fit" onClick={() => removeMedia(index, short.id)}>
                        Remove short
                      </button>
                    </div>
                  ) : null}
                  <div className="flex flex-wrap gap-2">
                    {photos.length < MEDIA.photosPerProject ? (
                      <label className="btn-line relative">
                        {uploading === `photo-${index}` ? "Adding photo…" : "Add photo"}
                        <input
                          className="sr-only"
                          type="file"
                          accept="image/jpeg,image/png,image/webp"
                          disabled={uploading !== ""}
                          onChange={(event) => {
                            const file = event.target.files?.[0] ?? null;
                            event.target.value = "";
                            void upload(index, "photo", file);
                          }}
                        />
                      </label>
                    ) : null}
                    {!short ? (
                      <label className="btn-line relative">
                        {uploading === `short-${index}` ? "Adding short…" : "Add short"}
                        <input
                          className="sr-only"
                          type="file"
                          accept="video/mp4,video/webm"
                          disabled={uploading !== ""}
                          onChange={(event) => {
                            const file = event.target.files?.[0] ?? null;
                            event.target.value = "";
                            void upload(index, "short", file);
                          }}
                        />
                      </label>
                    ) : null}
                  </div>
                </div>
              ) : null}
              <button type="button" className="btn-ghost w-fit" onClick={() => onChange(rows.filter((_, i) => i !== index))}>
                Remove project
              </button>
            </div>
          );
        })}
      </div>
      {rows.length < 12 ? (
        <button
          type="button"
          className="btn-line mt-4"
          onClick={() => onChange([...rows, { title: "", year: "", category: "", role: "", summary: "", media: [] }])}
        >
          Add project
        </button>
      ) : null}
    </fieldset>
  );
}

function updateProject(rows: Project[], index: number, partial: Partial<Project>, onChange: (rows: Project[]) => void) {
  onChange(rows.map((row, i) => (i === index ? { ...row, ...partial } : row)));
}

function Skills({ rows, onChange }: { rows: SkillGroup[]; onChange: (rows: SkillGroup[]) => void }) {
  return (
    <fieldset className="mt-12 border-0 p-0">
      <legend className="font-display text-2xl">Skills</legend>
      <div className="mt-4 grid gap-6">
        {rows.map((group, groupIndex) => (
          <div key={groupIndex} className="border border-ink/15 p-4">
            <Field
              label="Group"
              value={group.group}
              maxLength={40}
              onChange={(name) => onChange(rows.map((row, i) => (i === groupIndex ? { ...row, group: name } : row)))}
            />
            <div className="mt-3 grid gap-3">
              {group.items.map((item, itemIndex) => (
                <div key={itemIndex} className="grid gap-2 md:grid-cols-[1fr_1fr_auto]">
                  <input
                    className="field"
                    value={item.name}
                    placeholder="Skill"
                    maxLength={48}
                    onChange={(event) =>
                      onChange(
                        rows.map((row, i) =>
                          i === groupIndex
                            ? {
                                ...row,
                                items: row.items.map((skill, j) =>
                                  j === itemIndex ? { ...skill, name: event.target.value } : skill,
                                ),
                              }
                            : row,
                        ),
                      )
                    }
                  />
                  <input
                    className="field"
                    value={item.detail}
                    placeholder="Detail"
                    maxLength={80}
                    onChange={(event) =>
                      onChange(
                        rows.map((row, i) =>
                          i === groupIndex
                            ? {
                                ...row,
                                items: row.items.map((skill, j) =>
                                  j === itemIndex ? { ...skill, detail: event.target.value } : skill,
                                ),
                              }
                            : row,
                        ),
                      )
                    }
                  />
                  <button
                    type="button"
                    className="btn-ghost"
                    onClick={() =>
                      onChange(
                        rows.map((row, i) =>
                          i === groupIndex ? { ...row, items: row.items.filter((_, j) => j !== itemIndex) } : row,
                        ),
                      )
                    }
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {group.items.length < 8 ? (
                <button
                  type="button"
                  className="btn-line"
                  onClick={() =>
                    onChange(
                      rows.map((row, i) =>
                        i === groupIndex ? { ...row, items: [...row.items, { name: "", detail: "" }] } : row,
                      ),
                    )
                  }
                >
                  Add skill
                </button>
              ) : null}
              <button type="button" className="btn-ghost" onClick={() => onChange(rows.filter((_, i) => i !== groupIndex))}>
                Remove group
              </button>
            </div>
          </div>
        ))}
      </div>
      {rows.length < 6 ? (
        <button
          type="button"
          className="btn-line mt-4"
          onClick={() => onChange([...rows, { group: "", items: [{ name: "", detail: "" }] }])}
        >
          Add group
        </button>
      ) : null}
    </fieldset>
  );
}

function Links({
  rows,
  onChange,
}: {
  rows: { label: string; href: string }[];
  onChange: (rows: { label: string; href: string }[]) => void;
}) {
  return (
    <div>
      <p className="text-sm">Links — https only</p>
      <div className="mt-2 grid gap-3">
        {rows.map((row, index) => (
          <div key={index} className="grid gap-2 md:grid-cols-[10rem_1fr_auto]">
            <input
              className="field"
              value={row.label}
              placeholder="Label"
              maxLength={40}
              onChange={(event) => onChange(rows.map((item, i) => (i === index ? { ...item, label: event.target.value } : item)))}
            />
            <input
              className="field"
              value={row.href}
              placeholder="https://"
              maxLength={200}
              onChange={(event) => onChange(rows.map((item, i) => (i === index ? { ...item, href: event.target.value } : item)))}
            />
            <button type="button" className="btn-ghost" onClick={() => onChange(rows.filter((_, i) => i !== index))}>
              Remove
            </button>
          </div>
        ))}
      </div>
      {rows.length < 6 ? (
        <button type="button" className="btn-line mt-3" onClick={() => onChange([...rows, { label: "", href: "" }])}>
          Add link
        </button>
      ) : null}
    </div>
  );
}

function PhotoPreview({ id, src }: { id: string; src?: string }) {
  const [url, setUrl] = useState(src ?? "");
  useEffect(() => {
    if (src) {
      setUrl(src);
      return;
    }
    let cancel = false;
    readOwnMedia({ data: id })
      .then((result) => {
        if (cancel || !result.ok || !result.data.base64) return;
        setUrl(`data:${result.data.mime};base64,${result.data.base64}`);
      })
      .catch(() => undefined);
    return () => {
      cancel = true;
    };
  }, [id, src]);
  if (!url) return <p className="text-sm text-muted">Loading photo…</p>;
  return <img src={url} alt="" className="h-28 w-full object-cover" />;
}

async function sendMedia(versionId: string, kind: "photo" | "short", bytes: Uint8Array) {
  const started = await startMedia({ data: { versionId, kind, totalBytes: bytes.byteLength } });
  if (!started.ok) throw new Error(started.error);
  for (let offset = 0; offset < bytes.byteLength; offset += MEDIA.chunkBytes) {
    const slice = bytes.subarray(offset, Math.min(bytes.byteLength, offset + MEDIA.chunkBytes));
    const appended = await appendMedia({ data: { id: started.data.id, dataBase64: uint8ToBase64(slice) } });
    if (!appended.ok) throw new Error(appended.error);
  }
  const finished = await finishMedia({ data: started.data.id });
  if (!finished.ok) throw new Error(finished.error);
  return finished.data;
}

async function preparePhoto(file: File): Promise<{ bytes: Uint8Array; mime: "image/jpeg" }> {
  if (!file.type.startsWith("image/")) throw new Error("Choose a photo.");
  let bitmap: ImageBitmap;
  try {
    bitmap = await createImageBitmap(file);
  } catch {
    throw new Error("Use a JPEG, PNG, or WebP. That photo format could not be reduced.");
  }
  const scale = Math.min(1, 1600 / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not prepare that photo.");
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  let quality = 0.82;
  let blob: Blob | null = null;
  while (quality >= 0.5) {
    blob = await new Promise((resolve) => canvas.toBlob((value) => resolve(value), "image/jpeg", quality));
    if (blob && blob.size <= MEDIA.photoMaxBytes) break;
    quality -= 0.08;
  }
  if (!blob || blob.size > MEDIA.photoMaxBytes) throw new Error("That photo is still too large after reducing it.");
  return { bytes: new Uint8Array(await blob.arrayBuffer()), mime: "image/jpeg" };
}

async function prepareShort(file: File): Promise<{ bytes: Uint8Array; mime: "video/mp4" | "video/webm" }> {
  if (file.type !== "video/mp4" && file.type !== "video/webm") {
    throw new Error("Use an MP4 or WebM short. Files are stored as uploaded, not re-encoded.");
  }
  if (file.size > MEDIA.shortMaxBytes) {
    throw new Error("That short is over 8 MB. Export a smaller file — shorts are not re-encoded.");
  }
  const duration = await readDuration(file);
  if (duration > MEDIA.shortMaxSeconds + 0.25) throw new Error("Shorts need to be 30 seconds or less.");
  const mime = file.type === "video/webm" ? "video/webm" : "video/mp4";
  return { bytes: new Uint8Array(await file.arrayBuffer()), mime };
}

function readDuration(file: File): Promise<number> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const video = document.createElement("video");
    video.preload = "metadata";
    video.onloadedmetadata = () => {
      const duration = video.duration;
      URL.revokeObjectURL(url);
      if (!Number.isFinite(duration)) reject(new Error("Could not read the length of that short."));
      else resolve(duration);
    };
    video.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Could not read that short."));
    };
    video.src = url;
  });
}

function uint8ToBase64(bytes: Uint8Array): string {
  let binary = "";
  for (let i = 0; i < bytes.length; i += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  }
  return btoa(binary);
}
