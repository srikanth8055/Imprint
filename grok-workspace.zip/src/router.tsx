import { createRouter } from "@tanstack/react-router";
import { AppErrorComponent } from "@/lib/error-component";
import { routeTree } from "./routeTree.gen";

function NotFound() {
  return (
    <main className="shell flex min-h-screen flex-col justify-center py-24">
      <p className="text-xs font-medium tracking-eyebrow text-pine uppercase">Missing page</p>
      <h1 className="mt-3 font-display text-section">This page is not in the issue.</h1>
      <a href="/" className="btn-ink mt-8 w-fit">
        Back to Imprint
      </a>
    </main>
  );
}

export function getRouter() {
  return createRouter({
    routeTree,
    defaultErrorComponent: AppErrorComponent,
    defaultNotFoundComponent: NotFound,
    scrollRestoration: true,
  });
}
