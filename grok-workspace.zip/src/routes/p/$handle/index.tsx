import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { ProductBar } from "@/components/product-bar";
import { listPublicIssues } from "@/lib/portfolio.functions";

export const Route = createFileRoute("/p/$handle/")({
  loader: async ({ params }) => {
    const handle = params.handle.toLowerCase();
    if (handle !== params.handle) throw redirect({ to: "/p/$handle", params: { handle } });
    const issues = await listPublicIssues({ data: handle });
    if (issues.length === 1) {
      throw redirect({ to: "/p/$handle/$slug", params: { handle, slug: issues[0]!.slug } });
    }
    return { handle, issues };
  },
  head: ({ loaderData }) => ({
    meta: [{ title: loaderData ? `${loaderData.handle} — Imprint` : "Imprint" }],
  }),
  component: PublicIndex,
});

function PublicIndex() {
  const { handle, issues } = Route.useLoaderData();
  return (
    <>
      <ProductBar />
      <main id="content" className="shell py-16">
        <p className="text-xs font-medium tracking-eyebrow text-pine uppercase">Public versions</p>
        <h1 className="mt-3 font-display text-section">{handle}</h1>
        {issues.length === 0 ? (
          <p className="mt-6 max-w-md text-muted">Nothing is public at this address.</p>
        ) : (
          <ul className="mt-10 divide-y divide-ink/15 border-y border-ink/15">
            {issues.map((issue) => (
              <li key={issue.slug}>
                <Link
                  to="/p/$handle/$slug"
                  params={{ handle, slug: issue.slug }}
                  className="block py-6 hover:bg-wash"
                >
                  <p className="text-sm text-muted">{issue.title}</p>
                  <p className="mt-1 font-display text-3xl">{issue.name || issue.title}</p>
                  {issue.headline ? <p className="mt-2 max-w-xl text-muted">{issue.headline}</p> : null}
                  {issue.role ? <p className="mt-2 text-sm">{issue.role}</p> : null}
                </Link>
              </li>
            ))}
          </ul>
        )}
      </main>
    </>
  );
}
