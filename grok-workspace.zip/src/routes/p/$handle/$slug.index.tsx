import { createFileRoute } from "@tanstack/react-router";
import { IssueView } from "@/components/issue-view";
import { ProductBar } from "@/components/product-bar";
import { getPublicIssue } from "@/lib/portfolio.functions";

export const Route = createFileRoute("/p/$handle/$slug/")({
  loader: async ({ params }) => {
    const issue = await getPublicIssue({
      data: { handle: params.handle.toLowerCase(), slug: params.slug.toLowerCase() },
    });
    return { handle: params.handle.toLowerCase(), issue };
  },
  head: ({ loaderData }) => ({
    meta: [
      {
        title: loaderData?.issue
          ? `${loaderData.issue.content.name || loaderData.issue.title} — Imprint`
          : "Not public — Imprint",
      },
    ],
  }),
  component: PublicIssuePage,
});

function PublicIssuePage() {
  const { handle, issue } = Route.useLoaderData();
  if (!issue) {
    return (
      <>
        <ProductBar />
        <main className="shell py-20">
          <h1 className="font-display text-section">This version is not public.</h1>
          <p className="mt-4 text-muted">It may be a draft, or the address is wrong.</p>
        </main>
      </>
    );
  }
  return (
    <IssueView
      content={issue.content}
      issueLabel={issue.title}
      nav={{ kind: "member", handle, slug: issue.slug }}
      credit="member"
    />
  );
}
