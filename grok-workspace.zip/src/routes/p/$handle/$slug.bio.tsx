import { createFileRoute, Link } from "@tanstack/react-router";
import { BioView } from "@/components/issue-view";
import { ProductBar } from "@/components/product-bar";
import { getPublicIssue } from "@/lib/portfolio.functions";

export const Route = createFileRoute("/p/$handle/$slug/bio")({
  loader: async ({ params }) => {
    const issue = await getPublicIssue({
      data: { handle: params.handle.toLowerCase(), slug: params.slug.toLowerCase() },
    });
    return { handle: params.handle.toLowerCase(), issue };
  },
  head: ({ loaderData }) => ({
    meta: [
      {
        title: loaderData?.issue
          ? `Bio — ${loaderData.issue.content.name || loaderData.issue.title} — Imprint`
          : "Not public — Imprint",
      },
    ],
  }),
  component: PublicBioPage,
});

function PublicBioPage() {
  const { handle, issue } = Route.useLoaderData();
  if (!issue) {
    return (
      <>
        <ProductBar />
        <main className="shell py-20">
          <h1 className="font-display text-section">This bio is not public.</h1>
          <Link to="/p/$handle" params={{ handle }} className="btn-line mt-6">
            Public versions
          </Link>
        </main>
      </>
    );
  }
  return (
    <BioView
      content={issue.content}
      issueLabel={issue.title}
      nav={{ kind: "member", handle, slug: issue.slug }}
      credit="member"
    />
  );
}
