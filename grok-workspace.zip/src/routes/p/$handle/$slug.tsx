import { Outlet, createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/p/$handle/$slug")({
  component: function IssueLayout() {
    return <Outlet />;
  },
});
