import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ProductBar } from "@/components/product-bar";
import { PLAN_LIMITS } from "@/lib/portfolio-model";
import { setPlan } from "@/lib/portfolio.functions";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/plans")({
  head: () => ({
    meta: [
      { title: "Plans — Imprint" },
      { name: "description", content: "Free keeps two portfolio versions. A subscriber keeps four. Publish whichever you want." },
    ],
  }),
  component: PlansPage,
});

function PlansPage() {
  const { user, isPending } = useCurrentUserState();
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState<"free" | "subscriber" | null>(null);

  async function choose(plan: "free" | "subscriber") {
    setBusy(plan);
    setMessage("");
    try {
      const result = await setPlan({ data: plan });
      setMessage(result.ok ? `You are on ${PLAN_LIMITS[result.data.plan].label}.` : result.error);
    } catch (err) {
      setMessage(err instanceof Error ? err.message : "Could not change the plan.");
    } finally {
      setBusy(null);
    }
  }

  return (
    <>
      <ProductBar />
      <main id="content" className="shell py-14 md:py-20">
        <p className="text-xs font-medium tracking-eyebrow text-pine uppercase">Plans</p>
        <h1 className="mt-3 max-w-3xl font-display text-section">Two versions free. Four if you subscribe. Publish any of them.</h1>
        <p className="mt-4 max-w-2xl text-muted">
          A version is a full site: work with hover notes, about, skills, a contact form, and a bio page. Making one public does not hide the others. Visitors open the ones you mark public.
        </p>

        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          <article className="border border-ink/15 p-6">
            <h2 className="font-display text-3xl">Free</h2>
            <p className="mt-2 text-sm text-muted">$0</p>
            <ul className="mt-6 space-y-3 text-sm">
              <li>{PLAN_LIMITS.free.versions} versions in the studio</li>
              <li>Publish whichever of them you want</li>
              <li>Type-only covers — no hosted photos or shorts</li>
              <li>Each public version has its own link and bio</li>
              <li>Imprint credit in the footer</li>
            </ul>
            {user ? (
              <button type="button" className="btn-line mt-8" disabled={busy !== null} onClick={() => void choose("free")}>
                {busy === "free" ? "Switching…" : "Use Free"}
              </button>
            ) : null}
          </article>
          <article className="border border-ink bg-ink p-6 text-paper">
            <h2 className="font-display text-3xl">Subscriber</h2>
            <p className="mt-2 text-sm text-paper/70">No card in this studio</p>
            <ul className="mt-6 space-y-3 text-sm">
              <li>{PLAN_LIMITS.subscriber.versions} versions in the studio</li>
              <li>Publish any combination, including all four</li>
              <li>40 MB storage for photos and shorts</li>
              <li>3 photos and 1 short on each project</li>
              <li>Switch back to Free after you are down to two, with media removed</li>
            </ul>
            {user ? (
              <button type="button" className="btn-line on-ink mt-8" disabled={busy !== null} onClick={() => void choose("subscriber")}>
                {busy === "subscriber" ? "Switching…" : "Become a subscriber"}
              </button>
            ) : null}
          </article>
          <article className="border border-ink/15 bg-wash p-6">
            <p className="text-xs font-medium tracking-eyebrow text-pine uppercase">Suggested, not for sale</p>
            <h2 className="mt-2 font-display text-3xl">Press</h2>
            <ul className="mt-6 space-y-3 text-sm">
              <li>More than four versions</li>
              <li>More than 40 MB, plus video re-encoding</li>
              <li>A custom domain on the public link</li>
              <li>Footer credit removed</li>
              <li>One collaborator on the studio</li>
            </ul>
            <p className="mt-8 text-sm text-muted">Not built yet. Subscriber is the highest plan you can turn on.</p>
          </article>
        </div>

        {isPending ? <p className="mt-8 text-sm text-muted">Checking the session…</p> : null}
        {!isPending && !user ? (
          <p className="mt-8">
            <Link to="/login" className="btn-ink">
              Sign in to start on Free
            </Link>
          </p>
        ) : null}
        {message ? <p className="mt-6 max-w-xl text-sm">{message}</p> : null}

        <section className="mt-16 max-w-2xl border-t border-ink/15 pt-10">
          <h2 className="font-display text-3xl">How a version is used</h2>
          <ol className="mt-6 space-y-4">
            <li>
              <span className="font-medium">1. Write it.</span> Name, headline, projects, skills, about, and a bio.
            </li>
            <li>
              <span className="font-medium">2. Keep another.</span> A hiring issue beside a personal one. The second stays a draft until you say otherwise.
            </li>
            <li>
              <span className="font-medium">3. Publish the ones you mean.</span> Each public version has a link. If more than one is public, your name page lists them.
            </li>
          </ol>
          <p className="mt-6 text-sm text-muted">
            Turning on Subscriber does not charge a card. Billing is not connected, so the limit changes immediately and you can switch back.
            Storage is counted in megabytes. Photos are reduced in the browser before upload. Shorts are stored as the file you
            upload — there is no separate CPU pool to re-encode video.
          </p>
        </section>
      </main>
    </>
  );
}
