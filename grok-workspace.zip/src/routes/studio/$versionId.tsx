import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ProductBar } from "@/components/product-bar";
import { VersionEditor } from "@/components/version-editor";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { getStudio, getVersion } from "@/lib/portfolio.functions";
import type { PlanId, VersionDetail } from "@/lib/portfolio-model";

export const Route = createFileRoute("/studio/$versionId")({
  head: () => ({ meta: [{ title: "Edit version — Imprint" }] }),
  component: EditorGate,
});

function EditorGate() {
  const { user, isPending } = useCurrentUserState();
  const { versionId } = Route.useParams();
  if (isPending) {
    return (
      <>
        <ProductBar />
        <main className="shell py-20 text-muted">Opening the version…</main>
      </>
    );
  }
  if (!user) return <RedirectToSignIn />;
  return <EditorBody versionId={versionId} />;
}

function EditorBody({ versionId }: { versionId: string }) {
  const [version, setVersion] = useState<VersionDetail | null>(null);
  const [handle, setHandle] = useState("");
  const [plan, setPlan] = useState<PlanId>("free");
  const [storageUsed, setStorageUsed] = useState(0);
  const [storageLimit, setStorageLimit] = useState(0);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancel = false;
    Promise.all([getVersion({ data: versionId }), getStudio()])
      .then(([detail, studio]) => {
        if (cancel) return;
        if (!detail.ok) {
          setError(detail.error);
          return;
        }
        if (!studio.ok || studio.data.profile === null) {
          setError("Claim a public name before editing.");
          return;
        }
        setVersion(detail.data);
        setHandle(studio.data.profile.handle);
        setPlan(studio.data.profile.plan);
        setStorageUsed(studio.data.profile.storageUsed);
        setStorageLimit(studio.data.profile.storageLimit);
      })
      .catch((err: unknown) => {
        if (!cancel) setError(err instanceof Error ? err.message : "Could not load this version.");
      });
    return () => {
      cancel = true;
    };
  }, [versionId]);

  return (
    <>
      <ProductBar />
      {error ? (
        <main className="shell py-16">
          <p>{error}</p>
          <Link to="/studio" className="btn-line mt-6">
            Back to the studio
          </Link>
        </main>
      ) : null}
      {!error && !version ? <main className="shell py-16 text-muted">Loading this version…</main> : null}
      {version && handle ? (
        <VersionEditor
          version={version}
          handle={handle}
          plan={plan}
          storageUsed={storageUsed}
          storageLimit={storageLimit}
        />
      ) : null}
    </>
  );
}
