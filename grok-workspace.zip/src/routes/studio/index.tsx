import { useEffect, useState, type FormEvent } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ProductBar } from "@/components/product-bar";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { PLAN_LIMITS, formatBytes, parseHandle } from "@/lib/portfolio-model";
import {
  claimHandle,
  createVersion,
  deleteVersion,
  duplicateVersion,
  getStudio,
  setVisibility,
  type StudioData,
} from "@/lib/portfolio.functions";

export const Route = createFileRoute("/studio/")({
  head: () => ({ meta: [{ title: "Studio — Imprint" }] }),
  component: StudioGate,
});

function StudioGate() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) {
    return (
      <>
        <ProductBar />
        <main className="shell py-20 text-muted">Opening the studio…</main>
      </>
    );
  }
  if (!user) return <RedirectToSignIn />;
  return <StudioHome />;
}

function StudioHome() {
  const navigate = useNavigate();
  const [data, setData] = useState<StudioData | null>(null);
  const [error, setError] = useState("");
  const [handle, setHandle] = useState("");
  const [busy, setBusy] = useState("");

  async function refresh() {
    const result = await getStudio();
    if (!result.ok) {
      setError(result.error);
      return;
    }
    setData(result.data);
  }

  useEffect(() => {
    let cancel = false;
    getStudio()
      .then((result) => {
        if (cancel) return;
        if (!result.ok) setError(result.error);
        else setData(result.data);
      })
      .catch((err: unknown) => {
        if (!cancel) setError(err instanceof Error ? err.message : "Could not open the studio.");
      });
    return () => {
      cancel = true;
    };
  }, []);

  async function claim(event: FormEvent) {
    event.preventDefault();
    setBusy("claim");
    setError("");
    try {
      const result = await claimHandle({ data: handle });
      if (!result.ok) setError(result.error);
      else await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not claim that name.");
    } finally {
      setBusy("");
    }
  }

  async function addVersion() {
    if (!data || !data.profile) return;
    setBusy("create");
    setError("");
    try {
      const count = data.versions.length + 1;
      const result = await createVersion({ data: { title: `Issue ${count}` } });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      await navigate({ to: "/studio/$versionId", params: { versionId: result.data.id } });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not create a version.");
    } finally {
      setBusy("");
    }
  }

  async function run(id: string, action: "pub" | "unpub" | "copy" | "del") {
    setBusy(`${action}:${id}`);
    setError("");
    try {
      const result =
        action === "pub" || action === "unpub"
          ? await setVisibility({ data: { id, isPublic: action === "pub" } })
          : action === "copy"
            ? await duplicateVersion({ data: id })
            : await deleteVersion({ data: id });
      if (!result.ok) setError(result.error);
      else await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not update that version.");
    } finally {
      setBusy("");
    }
  }

  return (
    <>
      <ProductBar />
      <main id="content" className="shell py-12 md:py-16">
        <p className="text-xs font-medium tracking-eyebrow text-pine uppercase">Studio</p>
        <h1 className="mt-2 font-display text-section">Your versions</h1>
        {error ? <p className="mt-4 text-sm text-danger">{error}</p> : null}
        {!data ? <p className="mt-8 text-muted">Loading your issues…</p> : null}
        {data && data.profile === null ? (
          <form className="mt-8 max-w-md" onSubmit={(event) => void claim(event)}>
            <p className="text-muted">
              Claim a public name. It becomes the front of your links, like /p/your-name. Letters, numbers, and single hyphens. 3–24 characters.
            </p>
            <label className="mt-4 grid gap-1 text-sm">
              Public name
              <input className="field" value={handle} onChange={(event) => setHandle(event.target.value)} autoCapitalize="off" />
            </label>
            {handle && !parseHandle(handle) ? (
              <p className="mt-2 text-sm text-muted">That name will not be accepted yet.</p>
            ) : null}
            <button type="submit" className="btn-ink mt-4" disabled={busy === "claim"}>
              {busy === "claim" ? "Claiming…" : "Claim name"}
            </button>
          </form>
        ) : null}
        {data && data.profile ? (
          <>
            <p className="mt-4 max-w-2xl text-muted">
              {PLAN_LIMITS[data.profile.plan].label} · {data.profile.used} of {data.profile.versionLimit} versions ·{" "}
              {data.profile.publicCount} public
              {data.profile.plan === "subscriber"
                ? ` · ${formatBytes(data.profile.storageUsed)} of ${formatBytes(data.profile.storageLimit)} media. `
                : " · photos and shorts are on Subscriber. "}
              Your index is{" "}
              <Link to="/p/$handle" params={{ handle: data.profile.handle }} className="text-ink underline-offset-4 hover:underline">
                /p/{data.profile.handle}
              </Link>
              .
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              {data.profile.used >= data.profile.versionLimit ? (
                <Link to="/plans" className="btn-ink">
                  {data.profile.plan === "free" ? "Upgrade to keep four" : "At the four-version limit"}
                </Link>
              ) : (
                <button type="button" className="btn-ink" disabled={busy === "create"} onClick={() => void addVersion()}>
                  {busy === "create" ? "Creating…" : "New version"}
                </button>
              )}
              <Link to="/plans" className="btn-line">
                Plans
              </Link>
            </div>
            {data.versions.length === 0 ? (
              <p className="mt-10 max-w-lg text-muted">
                No versions yet. A version is the whole site — projects, about, skills, contact, and a bio. Start one, then publish it when you want it seen.
              </p>
            ) : (
              <ul className="mt-10 divide-y divide-ink/15 border-y border-ink/15">
                {data.versions.map((version) => (
                  <li key={version.id} className="grid gap-4 py-5 md:grid-cols-[1fr_auto] md:items-center">
                    <div>
                      <p className="font-display text-2xl">{version.title}</p>
                      <p className="mt-1 text-sm text-muted">
                        {version.isPublic ? "Public" : "Draft"}
                        {version.name ? ` · ${version.name}` : ""} · /p/{data.profile && data.profile.handle}/{version.slug}
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Link to="/studio/$versionId" params={{ versionId: version.id }} className="btn-line">
                        Edit
                      </Link>
                      <button
                        type="button"
                        className="btn-line"
                        disabled={busy === `pub:${version.id}` || busy === `unpub:${version.id}`}
                        onClick={() => void run(version.id, version.isPublic ? "unpub" : "pub")}
                      >
                        {version.isPublic ? "Unpublish" : "Publish"}
                      </button>
                      <button
                        type="button"
                        className="btn-ghost"
                        disabled={busy === `copy:${version.id}`}
                        onClick={() => void run(version.id, "copy")}
                      >
                        Duplicate
                      </button>
                      <button
                        type="button"
                        className="btn-ghost"
                        disabled={busy === `del:${version.id}`}
                        onClick={() => void run(version.id, "del")}
                      >
                        Delete
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </>
        ) : null}
      </main>
    </>
  );
}
