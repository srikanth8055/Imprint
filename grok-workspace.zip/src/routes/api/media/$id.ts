import { createFileRoute } from "@tanstack/react-router";
import { getSql } from "@/lib/db";
import { isMediaId } from "@/lib/portfolio-model";

function toBytes(value: unknown): Uint8Array | null {
  if (value instanceof Uint8Array) return value;
  if (typeof Buffer !== "undefined" && Buffer.isBuffer(value)) return new Uint8Array(value);
  if (value instanceof ArrayBuffer) return new Uint8Array(value);
  if (typeof value === "string" && value.startsWith("\\x")) {
    const hex = value.slice(2);
    if (hex.length % 2 !== 0) return null;
    const out = new Uint8Array(hex.length / 2);
    for (let i = 0; i < out.length; i += 1) out[i] = Number.parseInt(hex.slice(i * 2, i * 2 + 2), 16);
    return out;
  }
  return null;
}

function mediaResponse(request: Request, mime: string, bytes: Uint8Array): Response {
  const total = bytes.byteLength;
  const shared = {
    "content-type": mime,
    "accept-ranges": "bytes",
    "cache-control": "public, max-age=31536000, immutable",
    "x-content-type-options": "nosniff",
  };
  const range = request.headers.get("range");
  if (!range) {
    return new Response(Buffer.from(bytes), {
      headers: { ...shared, "content-length": String(total) },
    });
  }
  const match = /^bytes=(\d+)-(\d*)$/.exec(range);
  if (!match) {
    return new Response(null, { status: 416, headers: { "content-range": `bytes */${total}` } });
  }
  const start = Number(match[1]);
  const end = match[2] ? Number(match[2]) : total - 1;
  if (!Number.isFinite(start) || !Number.isFinite(end) || start > end || start >= total) {
    return new Response(null, { status: 416, headers: { "content-range": `bytes */${total}` } });
  }
  const safeEnd = Math.min(end, total - 1);
  const slice = bytes.subarray(start, safeEnd + 1);
  return new Response(Buffer.from(slice), {
    status: 206,
    headers: {
      ...shared,
      "content-length": String(slice.byteLength),
      "content-range": `bytes ${start}-${safeEnd}/${total}`,
    },
  });
}

export const Route = createFileRoute("/api/media/$id")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const id = new URL(request.url).pathname.split("/").filter(Boolean).pop()?.toLowerCase() ?? "";
        if (!isMediaId(id)) return new Response(null, { status: 404 });
        const sql = await getSql();
        const rows = await sql<{ mime: string; data: unknown }>`
          select m.mime, m.data
          from media m
          where m.id = ${id}
            and m.ready = true
            and m.mime in ('image/jpeg', 'video/mp4', 'video/webm')
            and exists (
              select 1
              from versions v
              where v.user_id = m.user_id
                and v.is_public = true
                and v.content::text like ${`%${id}%`}
            )
        `;
        const row = rows[0];
        const bytes = row ? toBytes(row.data) : null;
        if (!row || !bytes || bytes.byteLength === 0) return new Response(null, { status: 404 });
        return mediaResponse(request, row.mime, bytes);
      },
    },
  },
});
