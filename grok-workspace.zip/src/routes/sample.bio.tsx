import { createFileRoute } from "@tanstack/react-router";
import { ProductBar } from "@/components/product-bar";
import { BioView } from "@/components/issue-view";
import { specimen } from "@/data/specimen";

export const Route = createFileRoute("/sample/bio")({
  head: () => ({ meta: [{ title: "Bio — Specimen — Imprint" }] }),
  component: SampleBio,
});

function SampleBio() {
  return (
    <>
      <ProductBar notice="Specimen bio. Your versions get a bio page of their own." />
      <BioView content={specimen} issueLabel="Specimen" nav={{ kind: "sample" }} credit="specimen" />
    </>
  );
}
