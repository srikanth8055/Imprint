import { useState, type FormEvent } from "react";
import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { GROK_PROVIDERS, authClient, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { ProductBar } from "@/components/product-bar";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [{ title: "Sign in — Imprint" }] }),
  component: LoginPage,
});

function LoginPage() {
  const { user, isPending } = useCurrentUserState();
  const [mode, setMode] = useState<"in" | "up">("up");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  if (isPending) {
    return (
      <>
        <ProductBar />
        <main className="shell py-20 text-muted">Checking the session…</main>
      </>
    );
  }
  if (user || done) return <Navigate to="/studio" />;

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setError("");
    if (!email.includes("@") || password.length < 8) {
      setError("Use a real email and a password of at least 8 characters.");
      return;
    }
    if (mode === "up" && name.trim().length < 2) {
      setError("Add the name you want on the account.");
      return;
    }
    setBusy(true);
    try {
      const result =
        mode === "up"
          ? await authClient.signUp.email({ email: email.trim(), password, name: name.trim() })
          : await authClient.signIn.email({ email: email.trim(), password });
      if (result.error) {
        setError(result.error.message || "Could not sign in.");
        setBusy(false);
        return;
      }
      await authClient.getSession();
      setDone(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not sign in.");
      setBusy(false);
    }
  }

  return (
    <>
      <ProductBar />
      <main id="content" className="shell grid gap-12 py-14 md:grid-cols-2 md:py-20">
        <div>
          <p className="text-xs font-medium tracking-eyebrow text-pine uppercase">Account</p>
          <h1 className="mt-3 font-display text-section">Your name, in the versions you choose to publish.</h1>
          <p className="mt-4 max-w-md text-muted">
            Free keeps two versions. A subscriber keeps four, and 40 MB for photos and shorts. Either plan can make any of those versions public.
          </p>
          <Link to="/plans" className="mt-6 inline-block text-sm underline-offset-4 hover:underline">
            Compare plans
          </Link>
        </div>
        <div>
          <div className="flex gap-2" role="group" aria-label="Account mode">
            <button type="button" className="chip" aria-pressed={mode === "up"} onClick={() => setMode("up")}>
              Create account
            </button>
            <button type="button" className="chip" aria-pressed={mode === "in"} onClick={() => setMode("in")}>
              Sign in
            </button>
          </div>
          <form className="mt-6 grid gap-4" onSubmit={(event) => void onSubmit(event)} noValidate>
            {mode === "up" ? (
              <label className="grid gap-1 text-sm">
                Name
                <input className="field" value={name} autoComplete="name" onChange={(event) => setName(event.target.value)} />
              </label>
            ) : null}
            <label className="grid gap-1 text-sm">
              Email
              <input
                className="field"
                value={email}
                autoComplete="email"
                inputMode="email"
                onChange={(event) => setEmail(event.target.value)}
              />
            </label>
            <label className="grid gap-1 text-sm">
              Password
              <input
                className="field"
                type="password"
                value={password}
                autoComplete={mode === "up" ? "new-password" : "current-password"}
                onChange={(event) => setPassword(event.target.value)}
              />
            </label>
            {error ? <p className="text-sm text-danger">{error}</p> : null}
            <button type="submit" className="btn-ink w-fit" disabled={busy}>
              {busy ? "Please wait…" : mode === "up" ? "Create account" : "Sign in"}
            </button>
          </form>
          <div className="mt-8 grid gap-2">
            <p className="text-xs font-medium tracking-eyebrow text-muted uppercase">Or continue with</p>
            {GROK_PROVIDERS.map((provider) => (
              <button
                key={provider.providerId}
                type="button"
                className="btn-line"
                onClick={() => void signIn(provider.providerId, { callbackURL: "/studio" })}
              >
                Continue with {provider.label}
              </button>
            ))}
          </div>
        </div>
      </main>
    </>
  );
}
