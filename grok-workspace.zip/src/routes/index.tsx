import { createFileRoute } from "@tanstack/react-router";
import { ProductBar } from "@/components/product-bar";
import { IssueView } from "@/components/issue-view";
import { specimen } from "@/data/specimen";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Imprint — portfolio versions" },
      {
        name: "description",
        content: "Write a portfolio, keep a second version, and publish whichever you want. Free keeps two. Subscribers keep four.",
      },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <>
      <ProductBar notice="Specimen issue below — not a member. Sign in to publish your own. Free keeps 2 versions. A subscriber keeps 4, plus 40 MB for photos and shorts." />
      <IssueView content={specimen} issueLabel="Specimen" nav={{ kind: "sample" }} credit="specimen" />
    </>
  );
}
